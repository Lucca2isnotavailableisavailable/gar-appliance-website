# 🚀 GoDaddy Deployment Guide

## ✅ **Your Website is Ready!**

**Build Status**: ✅ Complete  
**Files Created**: `green-appliance-repairs-website.zip` (1.4MB)  
**Deployment Package**: Ready for upload

---

## 📋 **Step-by-Step GoDaddy Deployment**

### **Method 1: cPanel File Manager (Recommended)**

1. **Log into GoDaddy**
   - Go to [godaddy.com](https://godaddy.com)
   - Sign in to your account
   - Go to "My Products" → "Web Hosting"

2. **Access cPanel**
   - Click "Manage" next to your hosting plan
   - Click "cPanel Admin" 
   - Look for "File Manager" in the Files section

3. **Navigate to Website Root**
   - Open File Manager
   - Go to `public_html` folder (this is your website's root)
   - **IMPORTANT**: Delete any existing files in `public_html` first

4. **Upload Your Website**
   - Click "Upload" button
   - Select `green-appliance-repairs-website.zip`
   - Wait for upload to complete
   - Right-click the zip file → "Extract"
   - Delete the zip file after extraction

5. **Set Permissions (if needed)**
   - Select all files → "Permissions" → Set to 644
   - Select all folders → "Permissions" → Set to 755

### **Method 2: FTP Upload**

If you prefer FTP:
1. **Get FTP Details from GoDaddy**
   - Host: Usually your domain name
   - Username: Your cPanel username
   - Password: Your cPanel password
   - Port: 21

2. **Upload via FTP Client**
   - Use FileZilla, Cyberduck, or similar
   - Connect to your hosting
   - Navigate to `public_html`
   - Upload all contents from the `dist` folder

---

## 🌐 **After Upload**

### **Test Your Website**
1. **Visit your domain** (e.g., yourdomainname.com)
2. **Check all features**:
   - ✅ Homepage loads correctly
   - ✅ Chatbot appears and functions
   - ✅ Contact forms work
   - ✅ EmailJS sends emails
   - ✅ Mobile responsiveness
   - ✅ All images display

### **Common Issues & Fixes**

**🔧 Images Not Loading**
- Check file paths are correct
- Ensure image files uploaded to `/images/` folder

**🔧 Chatbot Not Working**
- Verify JavaScript files uploaded correctly
- Check browser console for errors

**🔧 EmailJS Not Sending**
- Confirm EmailJS credentials are correct
- Test from the live domain (not localhost)

**🔧 404 Errors on Page Refresh**
- Add `.htaccess` file to `public_html` with React routing rules

---

## 📧 **EmailJS Configuration**

Your EmailJS is configured with:
- **Service**: default_service
- **Template**: template_repair_request
- **Public Key**: SaFG0e9EcU7KVyvOm

**Make sure your EmailJS template is set up** with all the variables from `EMAILJS_TEMPLATE_GUIDE.md`

---

## 🎯 **Website Features Live**

Once deployed, your customers will have:

✅ **Smart Chatbot** - Auto-popup after 8 seconds  
✅ **Email Bookings** - Automatic repair request emails  
✅ **Mobile Responsive** - Perfect on all devices  
✅ **Professional Design** - Modern, clean interface  
✅ **Contact Forms** - Full customer details capture  
✅ **Appliance Selection** - Washing Machine, Dryer, Dishwasher, Oven  
✅ **Type Selection** - Integrated/Freestanding options  

---

## 🔄 **Future Updates**

To update your website:
1. Make changes to your code
2. Run `npm run build`
3. Upload new files to `public_html`
4. Clear browser cache

---

## 📞 **Support**

If you encounter issues:
1. **Check GoDaddy Help Center**
2. **Contact GoDaddy Support** - They can help with hosting issues
3. **Browser Console** - Check for JavaScript errors
4. **Test EmailJS** - Verify email functionality

**Your website is ready to go live! 🎉** 