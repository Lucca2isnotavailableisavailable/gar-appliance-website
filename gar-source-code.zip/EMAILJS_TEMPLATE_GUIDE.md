# EmailJS Template Setup Guide

## Template ID: `template_repair_request`

### Template Variables Used in Code:

```javascript
{
  to_email: 'luccaspenceley@yahoo.com',
  from_name: '{{customer_name}}',
  customer_name: '{{customer_name}}',
  customer_phone: '{{customer_phone}}',
  customer_email: '{{customer_email}}',
  booking_id: '{{booking_id}}',
  appliance: '{{appliance}}',
  appliance_type: '{{appliance_type}}',
  fault: '{{fault}}',
  address: '{{address}}',
  date_time: '{{date_time}}',
  contact_method: '{{contact_method}}',
  additional_info: '{{additional_info}}',
  message: '{{message}}'
}
```

## Suggested Email Template:

### Subject Line:
```
🔧 NEW REPAIR BOOKING - {{booking_id}}
```

### Email Body:
```
NEW REPAIR REQUEST RECEIVED
==========================

BOOKING DETAILS:
- Booking ID: {{booking_id}}
- Date & Time: {{date_time}}

CUSTOMER INFORMATION:
- Name: {{customer_name}}
- Phone: {{customer_phone}}
- Email: {{customer_email}}
- Address: {{address}}

APPLIANCE DETAILS:
- Appliance: {{appliance}}
- Type: {{appliance_type}}
- Problem: {{fault}}

CONTACT PREFERENCES:
- Preferred Contact Method: {{contact_method}}

ADDITIONAL INFORMATION:
{{additional_info}}

==========================
This booking was submitted via the Smart Repair Assistant.

Please contact the customer within 2 hours during business hours to confirm the appointment.

Best regards,
Smart Repair Assistant
```

## Setup Instructions:

1. **Go to EmailJS Dashboard** (https://dashboard.emailjs.com/)
2. **Navigate to Email Templates**
3. **Find template: `template_repair_request`**
4. **Copy the subject and body above**
5. **Make sure all variables are included: {{booking_id}}, {{customer_name}}, etc.**
6. **Test the template**

## Current Configuration:
- **Service ID**: default_service
- **Template ID**: template_repair_request  
- **Public Key**: SaFG0e9EcU7KVyvOm
- **Private Key**: NGKMjPI3EPt1VkQXfue_s

The system will now send professional booking emails automatically when customers submit repair requests! 