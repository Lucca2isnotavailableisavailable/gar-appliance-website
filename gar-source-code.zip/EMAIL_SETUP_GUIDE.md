# Email Setup Guide for Smart Chatbot

## Current Status
✅ **WORKING NOW**: The chatbot will open your default email client with all the repair request details pre-filled.

⚠️ **EmailJS Setup Required**: For automatic email sending without opening email client.

## How It Works Right Now

1. **Customer fills out the contact form**
2. **System generates a booking ID** (e.g., GAR-250118-1430-ABC)
3. **Opens your default email client** with:
   - To: luccaspenceley@yahoo.com
   - Subject: New Repair Request - [Booking ID]
   - Body: Complete customer details, appliance info, and booking details

## To Set Up Automatic EmailJS (Optional)

### Step 1: Create EmailJS Account
1. Go to [emailjs.com](https://www.emailjs.com/)
2. Sign up for a free account
3. Create a new service (Gmail, Outlook, etc.)

### Step 2: Create Email Template
Create a template with these variables:
- `{{from_name}}` - Customer name
- `{{customer_phone}}` - Phone number
- `{{customer_email}}` - Email address
- `{{booking_id}}` - Booking reference
- `{{appliance}}` - Appliance type
- `{{fault}}` - Problem description
- `{{address}}` - Full address
- `{{contact_method}}` - Preferred contact
- `{{message}}` - Complete formatted message

### Step 3: Update Configuration
In `src/components/ContactFormModal.jsx`, replace:
```javascript
const serviceID = 'service_gar_repairs'  // Your actual service ID
const templateID = 'template_gar_form'   // Your actual template ID  
const userID = 'your_emailjs_public_key' // Your actual public key
```

## Testing the Current Setup

1. **Open the website**
2. **Click the chatbot** (bottom right)
3. **Select an appliance and fault**
4. **Fill out the contact form**
5. **Submit** - Your email client should open with all details

## Troubleshooting

### Email Client Doesn't Open
- Check if you have a default email client set up
- Try different browsers
- Check browser popup blockers

### Missing Information
- All form fields are validated
- Booking ID is automatically generated
- Address is properly formatted

## Email Content Example

```
NEW REPAIR REQUEST RECEIVED
==========================

BOOKING DETAILS:
- Booking ID: GAR-250118-1430-ABC
- Date & Time: 18/01/2025 at 14:30:00

CUSTOMER INFORMATION:
- Name: John Smith
- Phone: 07932 123456
- Email: john.smith@email.com
- Address: 123 Main Street, London, Greater London, SW1A 1AA

APPLIANCE DETAILS:
- Appliance: Washing Machine
- Problem: Not spinning or draining

CONTACT PREFERENCES:
- Preferred Contact Method: phone

ADDITIONAL INFORMATION:
Machine makes strange noise before stopping

==========================
This booking was submitted via the Smart Repair Assistant.
```

## Benefits of Current Setup

✅ **Works immediately** - No setup required
✅ **All customer details captured**
✅ **Professional booking ID system**
✅ **Data saved locally** for backup
✅ **Form validation** ensures quality data
✅ **Mobile responsive** contact form

## Next Steps (Optional)

1. **Set up EmailJS** for automatic sending
2. **Add SMS notifications** via Twilio
3. **Integrate with CRM** system
4. **Add calendar booking** integration

The chatbot email system is fully functional and ready to capture leads! 