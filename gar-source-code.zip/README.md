# Green Appliance Repairs - Modern React Website

A beautiful, modern React website for Green Appliance Repairs, a family-run appliance repair business serving Sussex, Surrey, and Kent for over 25 years.

## 🌟 Features

- **Modern Design**: Clean, professional design with green/white color scheme
- **Smooth Animations**: Beautiful Framer Motion animations throughout
- **Mobile Responsive**: Fully responsive design that looks great on all devices
- **Interactive Elements**: Hover effects, animated backgrounds, and engaging UI
- **Service Showcase**: Comprehensive display of repair services and pricing
- **Location Finder**: Interactive location cards for all service areas
- **Customer Testimonials**: Real customer reviews with star ratings
- **Contact Form**: Professional contact form for booking engineers
- **Performance Optimized**: Built with Vite for fast loading times

## 🚀 Technologies Used

- **React 18** - Modern React with hooks
- **Vite** - Lightning fast build tool
- **Tailwind CSS** - Utility-first CSS framework
- **Framer Motion** - Smooth animations and interactions
- **Lucide React** - Beautiful, customizable icons
- **React Intersection Observer** - Trigger animations on scroll

## 📱 Sections

1. **Hero Section** - Eye-catching landing with animated appliance showcase
2. **Services** - Interactive service cards with pricing (£65-£85 freestanding, £85-£105 integrated)
3. **About** - Family business story with 25+ years experience
4. **Locations** - All 13 service locations across Sussex, Surrey & Kent
5. **Testimonials** - Real customer reviews from the current website
6. **Contact** - Professional contact form and business information
7. **Footer** - Comprehensive footer with links and contact details

## 🛠️ Quick Start

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Start development server:**
   ```bash
   npm run dev
   ```

3. **Build for production:**
   ```bash
   npm run build
   ```

4. **Preview production build:**
   ```bash
   npm run preview
   ```

## 📞 Business Information

- **Phone**: 0800 772 0226 (Free phone)
- **Services**: Washing machines, tumble dryers, dishwashers, electric ovens/cookers, integrated appliances
- **Coverage**: Sussex, Surrey, Kent and surrounding areas
- **Established**: 25+ years of family business experience
- **Guarantee**: 12-month warranty on all parts
- **Service**: Same day callouts available

## 🎨 Design Features

- **Green Primary Color**: #10B981 (representing the "Green" in company name)
- **Animated Background**: Floating particles and textured overlays
- **Appliance Icons**: Custom SVG icons for all appliance types
- **Smooth Scrolling**: Seamless navigation between sections
- **Hover Effects**: Interactive elements with scale and color transitions

## 📍 Service Locations

The website features all 13 service locations:
- Brighton (01273 978203)
- Crawley (01293 972056)  
- Horsham (01403 610047)
- East Grinstead (01342 618041)
- Haywards Heath (01444 702041)
- Worthing (01903 442094)
- Uckfield (01825 603018)
- Tunbridge Wells (01892 322083)
- Redhill (01737 902058)
- Caterham (01883 672029)
- Dorking (01306 302041)
- Leatherhead (01372 632096)


## 🎯 Key Selling Points Highlighted

- ✅ Same day service available
- ✅ Fixed rate pricing (no hidden costs)
- ✅ 12-month warranty on parts
- ✅ Family-run business (25+ years)
- ✅ Fully qualified and insured engineers
- ✅ Transparent pricing structure
- ✅ All major appliance brands serviced

## 📱 Mobile Optimization

The website is fully responsive with:
- Mobile-first design approach
- Touch-friendly navigation
- Optimized images and animations
- Fast loading times
- Accessible form controls

## 🔧 Development Notes

- Built with modern ES6+ JavaScript
- Uses CSS Grid and Flexbox for layouts
- Implements lazy loading for performance
- Follows React best practices
- Accessible design with proper ARIA labels
- SEO optimized with proper meta tags

## 🎊 Animations

- **Page Load**: Smooth fade-in animations
- **Scroll Triggers**: Elements animate in as they come into view
- **Hover Effects**: Subtle scale and color transitions
- **Background**: Floating particles and geometric shapes
- **Form Interactions**: Smooth state transitions

---

Built with ❤️ for a family business by creating a modern, professional web presence that reflects their quality service and 25+ years of expertise. 