import React from 'react'
import { motion } from 'framer-motion'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import BackgroundElements from './components/BackgroundElements'
import MobileCTA from './components/MobileCTA'
import EnhancedSmartChatbot from './components/EnhancedSmartChatbot'
import ScrollToTop from './components/ScrollToTop'
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import SalesHome from './pages/SalesHome'
import CategoryPage from './pages/CategoryPage'
import SubcategoryPage from './pages/SubcategoryPage'
import ProductPage from './pages/ProductPage'

function App() {
  return (
    <div className="relative min-h-screen bg-white overflow-hidden">
      <BackgroundElements />
      <ScrollToTop />
      
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="relative z-10 min-h-screen flex flex-col"
      >
        <Navbar />
        <MobileCTA />

        <main className="flex-1">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/sales" element={<SalesHome />} />
            <Route path="/sales/:category" element={<CategoryPage />} />
            <Route path="/sales/:category/:subcategory" element={<SubcategoryPage />} />
            <Route path="/sales/product/:id" element={<ProductPage />} />
            <Route path="*" element={<Home />} />
          </Routes>
        </main>

        <Footer />
      </motion.div>
      
      {/* Enhanced Smart Chatbot */}
      <EnhancedSmartChatbot />
    </div>
  )
}

export default App 