import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { MapPin, Phone, Clock } from 'lucide-react'

const Locations = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const [selectedLocation, setSelectedLocation] = useState(null)

  const locations = [
    { name: "Brighton & Hove", phone: "01273 978203", area: "East Sussex" },
    { name: "Crawley", phone: "01293 972056", area: "West Sussex" },
    { name: "Horsham", phone: "01403 610047", area: "West Sussex" },
    { name: "East Grinstead", phone: "01342 618041", area: "West Sussex" },
    { name: "Haywards Heath", phone: "01444 702041", area: "West Sussex" },
    { name: "Worthing", phone: "01903 442094", area: "West Sussex" },
    { name: "Uckfield", phone: "01825 603018", area: "East Sussex" },
    { name: "Tunbridge Wells", phone: "01892 322083", area: "Kent" },
    { name: "Redhill", phone: "01737 902058", area: "Surrey" },
    { name: "Caterham", phone: "01883 672029", area: "Surrey" },
    { name: "Dorking", phone: "01306 302041", area: "Surrey" },
    { name: "Leatherhead", phone: "01372 632096", area: "Surrey" }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  }

  const areas = [
    { area: "East Sussex", towns: ["Brighton", "Uckfield"], color: "bg-blue-100 text-blue-800" },
    { area: "West Sussex", towns: ["Horsham", "Crawley", "Worthing", "Haywards Heath"], color: "bg-green-100 text-green-800" },
    { area: "Surrey", towns: ["Redhill", "Caterham", "Dorking", "Leatherhead"], color: "bg-purple-100 text-purple-800" },
    { area: "Kent", towns: ["Tunbridge Wells"], color: "bg-orange-100 text-orange-800" }
  ]

  return (
    <section id="locations" className="section-padding bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.h2
              variants={itemVariants}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-6"
            >
              <span className="gradient-text">Service Locations</span> Across Sussex & Beyond
            </motion.h2>
            <motion.p
              variants={itemVariants}
              className="text-xl text-gray-600 max-w-3xl mx-auto"
            >
              We service East and West Sussex, Surrey and Kent and surrounding areas. Find your local branch below.
            </motion.p>
          </div>

          {/* Main Contact */}
          <motion.div
            variants={itemVariants}
            className="bg-gradient-to-r from-primary-500 to-primary-600 rounded-2xl p-8 mb-12 text-center text-white"
          >
            <h3 className="text-2xl font-bold mb-4">Call Us Free</h3>
            <div className="flex items-center justify-center space-x-3 mb-4">
              <Phone className="w-8 h-8" />
              <span className="text-4xl font-bold">0800 772 0226</span>
            </div>
            <p className="text-xl opacity-90">
              To speak to one of the team or Book an Engineer
            </p>
          </motion.div>

          {/* Locations Grid */}
          <motion.div
            variants={containerVariants}
            className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-12"
          >
            {locations.map((location, index) => (
              <motion.div
                key={location.name}
                variants={itemVariants}
                whileHover={{ scale: 1.02 }}
                onClick={() => setSelectedLocation(location)}
                className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 cursor-pointer hover:border-primary-200"
              >
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center">
                    <MapPin className="w-6 h-6 text-primary-600" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">{location.name}</h3>
                    <p className="text-sm text-gray-500">{location.area}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 text-primary-600 mb-3">
                  <Phone className="w-4 h-4" />
                  <span className="font-semibold">{location.phone}</span>
                </div>
                
                <div className="flex items-center space-x-2 text-gray-600 text-sm">
                  <Clock className="w-4 h-4" />
                  <span>Same day service available</span>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Service Areas Map Representation */}
          <motion.div
            variants={itemVariants}
            className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100"
          >
            <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Coverage Areas</h3>
            
            <div className="grid md:grid-cols-4 gap-8 text-center">
              {areas.map((region, index) => (
                <motion.div
                  key={region.area}
                  whileHover={{ scale: 1.05 }}
                  className="p-6 rounded-xl border border-gray-100 hover:shadow-lg transition-all duration-300"
                >
                  <div className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium mb-4 ${region.color}`}>
                    {region.area}
                  </div>
                  <ul className="space-y-2 text-sm text-gray-600">
                    {region.towns.map((town, idx) => (
                      <li key={idx} className="flex items-center justify-center space-x-2">
                        <div className="w-1.5 h-1.5 bg-primary-400 rounded-full"></div>
                        <span>{town}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Call to Action */}
          <motion.div
            variants={itemVariants}
            className="text-center mt-12"
          >
            <h3 className="text-xl font-semibold text-gray-900 mb-4">
              Don't see your area? Give us a call!
            </h3>
            <p className="text-gray-600 mb-6">
              We may still be able to help. Our coverage area is constantly expanding.
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="btn-primary"
            >
              Contact Us Today
            </motion.button>
          </motion.div>
        </motion.div>
      </div>

      {/* Selected Location Modal */}
      {selectedLocation && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedLocation(null)}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-2xl p-8 max-w-md w-full"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">{selectedLocation.name}</h3>
              <p className="text-gray-600 mb-6">{selectedLocation.area}</p>
              
              <div className="space-y-4 mb-8">
                <div className="flex items-center justify-center space-x-3">
                  <Phone className="w-5 h-5 text-primary-600" />
                  <span className="text-lg font-semibold">{selectedLocation.phone}</span>
                </div>
                <div className="flex items-center justify-center space-x-3 text-gray-600">
                  <Clock className="w-5 h-5" />
                  <span>Same day service available</span>
                </div>
              </div>
              
              <div className="flex space-x-4">
                <button
                  onClick={() => setSelectedLocation(null)}
                  className="flex-1 py-3 px-4 border border-gray-300 rounded-lg font-semibold text-gray-700 hover:bg-gray-50 transition-colors duration-300"
                >
                  Close
                </button>
                <button className="flex-1 btn-primary">
                  Call Now
                </button>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </section>
  )
}

export default Locations 