import { useEffect, useState } from 'react'

export const useMobileDetection = () => {
  const [isMobile, setIsMobile] = useState(false)
  const [isTablet, setIsTablet] = useState(false)

  useEffect(() => {
    const checkDevice = () => {
      const width = window.innerWidth
      setIsMobile(width <= 768)
      setIsTablet(width > 768 && width <= 1024)
    }

    checkDevice()
    window.addEventListener('resize', checkDevice)
    return () => window.removeEventListener('resize', checkDevice)
  }, [])

  return { isMobile, isTablet }
}

export const getChatbotStyles = (isMobile, isTablet) => {
  if (isMobile) {
    return {
      position: 'fixed',
      bottom: 0,
      left: 0,
      right: 0,
      width: '100%',
      height: '100vh',
      borderRadius: '0',
      maxHeight: '100vh'
    }
  }

  if (isTablet) {
    return {
      width: '420px',
      height: '550px',
      bottom: '20px',
      right: '20px'
    }
  }

  return {
    width: '400px',
    height: '600px',
    bottom: '24px',
    right: '24px'
  }
}

export const getMobileButtonStyles = (isMobile) => {
  if (isMobile) {
    return {
      bottom: '20px',
      right: '20px',
      transform: 'scale(0.9)'
    }
  }
  
  return {
    bottom: '24px',
    right: '24px'
  }
}

export default { useMobileDetection, getChatbotStyles, getMobileButtonStyles } 