import React from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Users, Award, Heart, Zap } from 'lucide-react'

const About = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const stats = [
    { number: "25+", label: "Years Experience", icon: Award },
    { number: "10,000+", label: "Happy Customers", icon: Heart },
    { number: "Same Day", label: "Service Available", icon: Zap },
    { number: "12 Month", label: "Parts Warranty", icon: Award }
  ]

  const values = [
    {
      title: "Reliability",
      description: "Same day call out option means no waiting around for us.",
      icon: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
    },
    {
      title: "Value for Money",
      description: "Our transparent pricing structure means there are no nasty surprises.",
      icon: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"
    },
    {
      title: "Fixed Fees",
      description: "We'll repair your appliance at a fixed fee…no matter how long the job takes.",
      icon: "M11.8 10.9c-2.27-.59-3-1.2-3-2.15 0-1.09 1.01-1.85 2.7-1.85 1.78 0 2.44.85 2.5 2.1h2.21c-.07-1.72-1.12-3.3-3.21-3.81V3h-3v2.16c-1.94.42-3.5 1.68-3.5 3.61 0 2.31 1.91 3.46 4.7 4.13 2.5.6 3 1.48 3 2.41 0 .69-.49 1.79-2.7 1.79-2.06 0-2.87-.92-2.98-2.1h-2.2c.12 2.19 1.76 3.42 3.68 3.83V21h3v-2.15c1.95-.37 3.5-1.5 3.5-3.55 0-2.84-2.43-3.81-4.7-4.4z"
    },
    {
      title: "Quality",
      description: "Our work is guaranteed for quality and all parts fitted have a 12 month warranty.",
      icon: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    },
    {
      title: "You're in Safe Hands",
      description: "All our engineers are fully qualified and insured.",
      icon: "M12 1l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"
    },
    {
      title: "Customer Satisfaction",
      description: "Customer service is not a department, it's our job.",
      icon: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  }

  return (
    <section id="about" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.h2
              variants={itemVariants}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-6"
            >
              <span className="gradient-text">Family Run</span> for Over 25 Years
            </motion.h2>
            <motion.p
              variants={itemVariants}
              className="text-xl text-gray-600 max-w-3xl mx-auto"
            >
              At Green Appliance Repairs, we're committed to providing exceptional appliance repair services with over 25 years of expertise in Sussex.
            </motion.p>
          </div>

          {/* Trust Images Gallery - Moved to top */}
          <motion.div variants={itemVariants} className="mb-16">
            <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">Professional Service You Can Trust</h3>
            <div className="grid md:grid-cols-3 gap-6">
              <motion.div
                whileHover={{ scale: 1.03 }}
                className="relative overflow-hidden rounded-xl shadow-lg"
              >
                <img 
                  src="/images/gar2.jpg" 
                  alt="Green Appliance Repairs Work Estimate"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-4 text-white">
                    <h4 className="font-semibold">Professional Estimates</h4>
                    <p className="text-sm opacity-90">Transparent pricing and detailed work estimates</p>
                  </div>
                </div>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.03 }}
                className="relative overflow-hidden rounded-xl shadow-lg"
              >
                <img 
                  src="/images/gar1.jpg" 
                  alt="Green Appliance Repairs Service Van"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-4 text-white">
                    <h4 className="font-semibold">Local Service</h4>
                    <p className="text-sm opacity-90">Same-day call out available</p>
                  </div>
                </div>
              </motion.div>
              
              <motion.div
                whileHover={{ scale: 1.03 }}
                className="relative overflow-hidden rounded-xl shadow-lg"
              >
                <img 
                  src="/images/gar3.jpg" 
                  alt="Professional Appliance Repair Technology"
                  className="w-full h-64 object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                  <div className="p-4 text-white">
                    <h4 className="font-semibold">Modern Technology</h4>
                    <p className="text-sm opacity-90">Latest diagnostic tools and repair techniques</p>
                  </div>
                </div>
              </motion.div>
            </div>
          </motion.div>

          {/* Main Content Grid */}
          <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
            {/* Story Section */}
            <motion.div variants={itemVariants}>
              <div className="prose prose-lg">
                <h3 className="text-2xl font-bold text-gray-900 mb-6">Our Story</h3>
                <p className="text-gray-600 mb-6">
                  We are a family run business with over 20 years of experience in white good repairs and are one of the most trustworthy appliance repair specialists in Sussex.
                </p>
                <p className="text-gray-600 mb-6">
                  Our promise is straightforward: fast, reliable service, transparent pricing, and a commitment to excellence. Backed by our fixed costs model and quality guarantee, you can trust us to keep your appliances running efficiently.
                </p>
                <p className="text-gray-600">
                  We believe that you can save pounds on having your appliance repaired rather than replacing it every few years – it's also better for the environment. We source 90% of our parts and can usually complete repairs within 24-48 hours.
                </p>
              </div>
            </motion.div>

            {/* Stats Grid */}
            <motion.div variants={itemVariants} className="grid grid-cols-2 gap-6">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  className="bg-gradient-to-br from-primary-50 to-primary-100 rounded-2xl p-6 text-center"
                >
                  <stat.icon className="w-8 h-8 text-primary-600 mx-auto mb-3" />
                  <div className="text-3xl font-bold text-primary-600 mb-2">{stat.number}</div>
                  <div className="text-sm font-medium text-gray-700">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Our Expertise Values */}
          <motion.div variants={itemVariants} className="mb-16">
            <h3 className="text-2xl font-bold text-gray-900 text-center mb-12">Our Expertise</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={index}
                  variants={itemVariants}
                  whileHover={{ scale: 1.02 }}
                  className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300"
                >
                  <div className="w-12 h-12 bg-primary-100 rounded-lg flex items-center justify-center mb-4">
                    <svg className="w-6 h-6 text-primary-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d={value.icon} />
                    </svg>
                  </div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">{value.title}</h4>
                  <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Call to Action */}
          <motion.div
            variants={itemVariants}
            className="bg-gradient-to-r from-primary-500 to-primary-600 rounded-2xl p-8 md:p-12 text-center text-white"
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Ready to Get Your Appliance Fixed?
            </h3>
            <p className="text-xl mb-8 opacity-90">
              Call us today for same-day service and transparent pricing
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-white text-primary-600 font-semibold py-3 px-8 rounded-lg hover:bg-gray-50 transition-colors duration-300"
              >
                Call: 0800 772 0226
              </motion.button>
              <motion.a
                href="#contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border-2 border-white text-white font-semibold py-3 px-8 rounded-lg hover:bg-white hover:text-primary-600 transition-all duration-300 inline-block"
              >
                Book an Engineer
              </motion.a>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

export default About 