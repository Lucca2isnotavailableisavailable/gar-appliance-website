import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { User, Phone, Mail, MapPin, Send, CheckCircle, AlertCircle } from 'lucide-react'
import emailjs from '@emailjs/browser'

// Initialize EmailJS
emailjs.init('SaFG0e9EcU7KVyvOm')

const ContactFormModal = ({ isOpen, onClose, appliance, applianceType, fault, onSubmitSuccess }) => {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    phoneConfirm: '',
    email: '',
    houseNumber: '',
    streetName: '',
    townCity: '',
    county: '',
    postcode: '',
    contactMethod: 'phone',
    additionalInfo: ''
  })

  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState('')

  const counties = [
    '', 'East Sussex', 'West Sussex', 'Surrey', 'Kent', 'Hampshire', 'London', 'Other'
  ]

  const validateField = (name, value) => {
    let error = ''
    
    switch (name) {
      case 'name':
        if (value.length < 2) error = 'Please enter your full name'
        break
      case 'phone':
        const cleanPhone = value.replace(/[\s\-\(\)]/g, '')
        const phoneRegex = /^(\+44|0044|44)?[67]\d{9}$|^0[1-9]\d{8,10}$/
        if (!phoneRegex.test(cleanPhone)) {
          error = 'Please enter a valid UK phone number'
        }
        break
      case 'phoneConfirm':
        const cleanOriginal = formData.phone.replace(/[\s\-\(\)]/g, '')
        const cleanConfirm = value.replace(/[\s\-\(\)]/g, '')
        if (cleanConfirm !== cleanOriginal) {
          error = 'Phone numbers do not match'
        } else if (cleanConfirm.length === 0) {
          error = 'Please confirm your phone number'
        }
        break
      case 'email':
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
        if (!emailRegex.test(value)) error = 'Please enter a valid email address'
        break
      case 'houseNumber':
        if (value.length < 1) error = 'Please enter house number/name'
        break
      case 'streetName':
        if (value.length < 2) error = 'Please enter street name'
        break
      case 'townCity':
        if (value.length < 2) error = 'Please enter town/city'
        break
      case 'postcode':
        const postcodeRegex = /^[A-Z]{1,2}[0-9]{1,2}[A-Z]?\s?[0-9][A-Z]{2}$/i
        if (!postcodeRegex.test(value)) error = 'Please enter a valid UK postcode'
        break
    }
    
    return error
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }))
    }
  }

  const handleBlur = (e) => {
    const { name, value } = e.target
    const error = validateField(name, value)
    setErrors(prev => ({ ...prev, [name]: error }))
  }

  const generateBookingId = () => {
    const date = new Date()
    const dateStr = date.getFullYear().toString().substr(-2) + 
                   String(date.getMonth() + 1).padStart(2, '0') + 
                   String(date.getDate()).padStart(2, '0')
    const timeStr = String(date.getHours()).padStart(2, '0') + 
                   String(date.getMinutes()).padStart(2, '0')
    const randomStr = Math.random().toString(36).substr(2, 3).toUpperCase()
    
    return `GAR-${dateStr}-${timeStr}-${randomStr}`
  }

  const createEmailBody = (bookingId) => {
    const date = new Date()
    const formattedDate = date.toLocaleDateString('en-GB')
    const formattedTime = date.toLocaleTimeString('en-GB')
    const fullAddress = `${formData.houseNumber} ${formData.streetName}, ${formData.townCity}${formData.county ? ', ' + formData.county : ''}, ${formData.postcode}`
    
    return `
NEW REPAIR REQUEST RECEIVED
==========================

BOOKING DETAILS:
- Booking ID: ${bookingId}
- Date & Time: ${formattedDate} at ${formattedTime}

CUSTOMER INFORMATION:
- Name: ${formData.name}
- Phone: ${formData.phone}
- Email: ${formData.email}
- Address: ${fullAddress}

APPLIANCE DETAILS:
- Appliance: ${appliance}${applianceType ? `\n- Type: ${applianceType}` : ''}
- Problem: ${fault}

CONTACT PREFERENCES:
- Preferred Contact Method: ${formData.contactMethod}

ADDITIONAL INFORMATION:
${formData.additionalInfo || 'None provided'}

==========================
This booking was submitted via the Smart Repair Assistant.

Please contact the customer within 2 hours during business hours to confirm the appointment.

Best regards,
Smart Repair Assistant
    `.trim()
  }

  const sendViaEmailJS = async (bookingId) => {
    // EmailJS configuration - LIVE CREDENTIALS
    const serviceID = 'default_service'      // EmailJS default service
    const templateID = 'template_repair_request'  // Your actual template ID
    const userID = 'SaFG0e9EcU7KVyvOm'     // Your actual public key
    
    const fullAddress = `${formData.houseNumber} ${formData.streetName}, ${formData.townCity}${formData.county ? ', ' + formData.county : ''}, ${formData.postcode}`
    
    const templateParams = {
      to_email: 'luccaspenceley@yahoo.com',
      from_name: formData.name,
      customer_name: formData.name,
      customer_phone: formData.phone,
      customer_email: formData.email,
      booking_id: bookingId,
      appliance: appliance,
      appliance_type: applianceType || 'Not specified',
      fault: fault,
      address: fullAddress,
      date_time: new Date().toLocaleString('en-GB'),
      contact_method: formData.contactMethod,
      additional_info: formData.additionalInfo || 'None provided',
      message: createEmailBody(bookingId)
    }

    try {
      console.log('📧 Sending email via EmailJS...', {
        serviceID,
        templateID,
        userID: userID.substring(0, 8) + '...',
        bookingId,
        templateParams
      })
      
      setSubmitStatus('Sending email...')
      const result = await emailjs.send(serviceID, templateID, templateParams, userID)
      console.log('✅ Email sent successfully via EmailJS:', result)
      setSubmitStatus('Email sent successfully!')
      return true
    } catch (error) {
      console.error('❌ EmailJS failed:', error)
      console.error('Error details:', error.text || error.message)
      setSubmitStatus('Email failed, trying backup method...')
      console.log('📧 Attempting fallback email method...')
      return await sendViaMailto(bookingId)
    }
  }

  const sendViaMailto = async (bookingId) => {
    try {
      const fullAddress = `${formData.houseNumber} ${formData.streetName}, ${formData.townCity}${formData.county ? ', ' + formData.county : ''}, ${formData.postcode}`
      const subject = encodeURIComponent(`🔧 NEW REPAIR BOOKING - ${bookingId}`)
      const body = encodeURIComponent(createEmailBody(bookingId))
      
      const mailtoLink = `mailto:luccaspenceley@yahoo.com?subject=${subject}&body=${body}`
      
      // Create a hidden link and click it to send email
      const link = document.createElement('a')
      link.href = mailtoLink
      link.style.display = 'none'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      
      console.log('📧 Booking details sent via email:', {
        bookingId,
        customer: formData.name,
        phone: formData.phone,
        email: formData.email,
        address: fullAddress,
        appliance,
        fault,
        contactMethod: formData.contactMethod,
        additionalInfo: formData.additionalInfo
      })
      
      return true
    } catch (error) {
      console.error('❌ Email sending failed:', error)
      return false
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Validate all fields
    const requiredFields = ['name', 'phone', 'phoneConfirm', 'email', 'houseNumber', 'streetName', 'townCity', 'postcode']
    const newErrors = {}
    
    requiredFields.forEach(field => {
      const error = validateField(field, formData[field])
      if (error) newErrors[field] = error
    })

    setErrors(newErrors)

    if (Object.keys(newErrors).length === 0) {
      const bookingId = generateBookingId()
      
      // Save to localStorage
      const repairRequest = {
        ...formData,
        appliance,
        applianceType,
        fault,
        bookingId,
        timestamp: new Date().toISOString(),
        address: `${formData.houseNumber} ${formData.streetName}, ${formData.townCity}${formData.county ? ', ' + formData.county : ''}, ${formData.postcode}`
      }
      
      const existingRequests = JSON.parse(localStorage.getItem('repairRequests') || '[]')
      existingRequests.unshift(repairRequest)
      if (existingRequests.length > 100) {
        existingRequests.slice(0, 100)
      }
      localStorage.setItem('repairRequests', JSON.stringify(existingRequests))

      // Send email
      const emailSent = await sendViaEmailJS(bookingId)
      
      // Call success callback
      onSubmitSuccess(bookingId, emailSent)
      
      // Reset form
      setFormData({
        name: '', phone: '', phoneConfirm: '', email: '', houseNumber: '',
        streetName: '', townCity: '', county: '', postcode: '',
        contactMethod: 'phone', additionalInfo: ''
      })
      setSubmitStatus('')
    }
    
    setIsSubmitting(false)
  }

  if (!isOpen) return null

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.9, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-y-auto"
      >
        <div className="p-6">
          <div className="text-center mb-6">
            <h2 className="text-xl font-semibold text-gray-800">Contact Details</h2>
            <p className="text-sm text-gray-600 mt-1">
              {appliance}{applianceType ? ` (${applianceType})` : ''} - {fault}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Personal Information */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Full Name *
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Enter your full name"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                      errors.name ? 'border-red-300' : 'border-gray-300'
                    }`}
                    required
                  />
                </div>
                {errors.name && (
                  <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {errors.name}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Mobile Number *
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="e.g. 07932 123456"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                      errors.phone ? 'border-red-300' : 'border-gray-300'
                    }`}
                    required
                  />
                </div>
                {errors.phone && (
                  <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {errors.phone}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm Mobile Number *
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="tel"
                    name="phoneConfirm"
                    value={formData.phoneConfirm}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Re-enter your mobile number"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                      errors.phoneConfirm ? 'border-red-300' : 'border-gray-300'
                    }`}
                    required
                  />
                </div>
                {errors.phoneConfirm && (
                  <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {errors.phoneConfirm}
                  </p>
                )}
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email Address *
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="your.email@example.com"
                    className={`w-full pl-10 pr-4 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                      errors.email ? 'border-red-300' : 'border-gray-300'
                    }`}
                    required
                  />
                </div>
                {errors.email && (
                  <p className="text-red-500 text-xs mt-1 flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {errors.email}
                  </p>
                )}
              </div>
            </div>

            {/* Address Information */}
            <div className="border-t pt-4">
              <h3 className="text-sm font-medium text-gray-700 mb-3 flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Your Address *
              </h3>
              
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <input
                      type="text"
                      name="houseNumber"
                      value={formData.houseNumber}
                      onChange={handleInputChange}
                      onBlur={handleBlur}
                      placeholder="House No/Name"
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                        errors.houseNumber ? 'border-red-300' : 'border-gray-300'
                      }`}
                      required
                    />
                    {errors.houseNumber && (
                      <p className="text-red-500 text-xs mt-1">{errors.houseNumber}</p>
                    )}
                  </div>
                  
                  <div>
                    <input
                      type="text"
                      name="streetName"
                      value={formData.streetName}
                      onChange={handleInputChange}
                      onBlur={handleBlur}
                      placeholder="Street Name"
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                        errors.streetName ? 'border-red-300' : 'border-gray-300'
                      }`}
                      required
                    />
                    {errors.streetName && (
                      <p className="text-red-500 text-xs mt-1">{errors.streetName}</p>
                    )}
                  </div>
                </div>

                <div>
                  <input
                    type="text"
                    name="townCity"
                    value={formData.townCity}
                    onChange={handleInputChange}
                    onBlur={handleBlur}
                    placeholder="Town/City"
                    className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent ${
                      errors.townCity ? 'border-red-300' : 'border-gray-300'
                    }`}
                    required
                  />
                  {errors.townCity && (
                    <p className="text-red-500 text-xs mt-1">{errors.townCity}</p>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <select
                    name="county"
                    value={formData.county}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="">Select County</option>
                    {counties.slice(1).map(county => (
                      <option key={county} value={county}>{county}</option>
                    ))}
                  </select>
                  
                  <div>
                    <input
                      type="text"
                      name="postcode"
                      value={formData.postcode}
                      onChange={handleInputChange}
                      onBlur={handleBlur}
                      placeholder="Postcode"
                      className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent uppercase ${
                        errors.postcode ? 'border-red-300' : 'border-gray-300'
                      }`}
                      required
                    />
                    {errors.postcode && (
                      <p className="text-red-500 text-xs mt-1">{errors.postcode}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Preferences */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Preferred Contact Method
              </label>
              <select
                name="contactMethod"
                value={formData.contactMethod}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
              >
                <option value="phone">Phone Call</option>
                <option value="sms">Text Message</option>
                <option value="email">Email</option>
              </select>
            </div>

            {/* Additional Information */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Additional Information
              </label>
              <textarea
                name="additionalInfo"
                value={formData.additionalInfo}
                onChange={handleInputChange}
                placeholder="Any other details about the problem or preferred appointment times..."
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none"
              />
            </div>

            {/* Status Display */}
            {submitStatus && (
              <div className="text-center p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-700">{submitStatus}</p>
              </div>
            )}

            {/* Submit Button */}
            <div className="flex gap-3 pt-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex-1 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 disabled:from-gray-300 disabled:to-gray-400 text-white px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    Submitting...
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    Book My Repair
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default ContactFormModal