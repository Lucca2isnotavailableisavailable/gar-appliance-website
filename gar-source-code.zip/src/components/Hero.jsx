import React from 'react'
import { motion } from 'framer-motion'
import { Phone, Clock, Shield, Star } from 'lucide-react'

const Hero = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  }

  const floatingApplianceVariants = {
    animate: {
      y: [-10, 10, -10],
      rotate: [-2, 2, -2],
      transition: {
        duration: 6,
        repeat: Infinity,
        ease: "easeInOut"
      }
    }
  }

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-20 section-padding">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid lg:grid-cols-2 gap-12 items-center"
        >
          {/* Content */}
          <div className="text-center lg:text-left">
            <motion.div
              variants={itemVariants}
              className="inline-flex items-center space-x-2 bg-primary-100 text-primary-700 px-4 py-2 rounded-full text-sm font-medium mb-6"
            >
              <Star className="w-4 h-4" />
              <span>25+ Years of Excellence</span>
            </motion.div>

            <motion.h1
              variants={itemVariants}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight"
            >
              <span className="gradient-text">Speedy, Reliable</span>
              <br />
              Appliance Repair
            </motion.h1>

            <motion.p
              variants={itemVariants}
              className="text-xl text-gray-600 mb-8 max-w-2xl"
            >
              Professional domestic appliance service engineers repairing all brands of home appliances across Sussex. Same day service with transparent, fixed pricing.
            </motion.p>

            <motion.div
              variants={itemVariants}
              className="flex flex-col sm:flex-row gap-4 mb-8"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-primary flex items-center justify-center space-x-2"
              >
                <Phone className="w-5 h-5" />
                <span>Call Free: 0800 772 0226</span>
              </motion.button>
              
              <motion.a
                href="#contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="btn-secondary inline-block text-center"
              >
                Book an Engineer
              </motion.a>
            </motion.div>

            {/* Key Features */}
            <motion.div
              variants={itemVariants}
              className="grid grid-cols-1 sm:grid-cols-3 gap-6"
            >
              {[
                { icon: Clock, text: "Same Day Service", color: "text-blue-600" },
                { icon: Shield, text: "12 Month Warranty", color: "text-green-600" },
                { icon: Star, text: "Fixed Rate Pricing", color: "text-yellow-600" }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  whileHover={{ scale: 1.05 }}
                  className="flex items-center space-x-3 p-4 bg-white/80 backdrop-blur-sm rounded-lg shadow-sm border border-gray-100"
                >
                  <feature.icon className={`w-6 h-6 ${feature.color}`} />
                  <span className="font-medium text-gray-700">{feature.text}</span>
                </motion.div>
              ))}
            </motion.div>
          </div>

          {/* Animated Appliances Showcase */}
          <div className="relative">
            <div className="relative w-full h-96 lg:h-[500px]">
              {/* Central appliance - Washing Machine */}
              <motion.div
                variants={floatingApplianceVariants}
                animate="animate"
                className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-10"
              >
                <div className="w-32 h-32 bg-gradient-to-br from-primary-500 to-primary-600 rounded-2xl shadow-2xl flex items-center justify-center">
                  <svg className="w-16 h-16 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18 2.01L6 2c-1.11 0-2 .89-2 2v16c0 1.11.89 2 2 2h12c1.11 0 2-.89 2-2V4c0-1.11-.89-1.99-2-1.99zM18 20H6V4h12v16zM8 5h2v2H8V5zm0 3h8v8H8V8z"/>
                  </svg>
                </div>
              </motion.div>

              {/* Floating Elements - Clean & Simple */}
              {[
                { 
                  type: 'logo',
                  position: "top-8 left-12", 
                  delay: 0.2,
                  size: "w-16 h-16",
                  rotation: 12
                },
                { 
                  type: 'washing-machine',
                  icon: "M18 2.01L6 2c-1.11 0-2 .89-2 2v16c0 1.11.89 2 2 2h12c1.11 0 2-.89 2-2V4c0-1.11-.89-1.99-2-1.99zM18 20H6V4h12v16zM8 5h2v2H8V5zm4 1c1.66 0 3 1.34 3 3s-1.34 3-3 3-3-1.34-3-3 1.34-3 3-3z",
                  position: "top-20 right-8", 
                  delay: 0.6,
                  size: "w-14 h-14",
                  rotation: -8
                },
                { 
                  type: 'recycle',
                  position: "bottom-24 left-8", 
                  delay: 1.0,
                  size: "w-12 h-12",
                  rotation: 15
                },
                { 
                  type: 'wrench',
                  icon: "M22.7 19L13.6 9.9C14.5 7.6 14 4.9 12.1 3C10.1 1 7.1 0.6 4.7 1.7L9 6L6 9L1.6 4.7C0.4 7.1 0.9 10.1 2.9 12.1C4.8 14 7.5 14.5 9.8 13.6L18.9 22.7C19.3 23.1 19.9 23.1 20.3 22.7L22.6 20.4C23.1 20 23.1 19.3 22.7 19Z",
                  position: "bottom-12 right-12", 
                  delay: 1.4,
                  size: "w-13 h-13",
                  rotation: -12
                }
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ 
                    scale: 0, 
                    opacity: 0, 
                    rotate: item.rotation - 20,
                    y: 30
                  }}
                  animate={{ 
                    scale: 1, 
                    opacity: 0.8,
                    y: [-12, 12, -12],
                    x: [-4, 4, -4],
                    rotate: [item.rotation - 3, item.rotation + 3, item.rotation - 3]
                  }}
                  transition={{ 
                    delay: item.delay,
                    duration: 1,
                    scale: { duration: 0.8, ease: "backOut" },
                    opacity: { duration: 0.6 },
                    y: { duration: 6 + index * 0.8, repeat: Infinity, ease: "easeInOut" },
                    x: { duration: 8 + index * 0.5, repeat: Infinity, ease: "easeInOut" },
                    rotate: { duration: 12 + index * 2, repeat: Infinity, ease: "easeInOut" }
                  }}
                  whileHover={{ 
                    scale: 1.1,
                    opacity: 1,
                    y: -15,
                    transition: { duration: 0.2 }
                  }}
                  className={`absolute ${item.position} ${item.size} bg-white/60 backdrop-blur-md rounded-3xl shadow-lg flex items-center justify-center hover:shadow-xl transition-all duration-300`}
                >
                  {item.type === 'logo' ? (
                    <div className="w-14 h-14 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center">
                      <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z"/>
                      </svg>
                    </div>
                  ) : item.type === 'recycle' ? (
                    <svg className="w-10 h-10 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M21,12A9,9 0 0,1 12,21A9,9 0 0,1 3,12A9,9 0 0,1 12,3A9,9 0 0,1 21,12M17.5,12A5.5,5.5 0 0,0 12,6.5A5.5,5.5 0 0,0 6.5,12A5.5,5.5 0 0,0 12,17.5A5.5,5.5 0 0,0 17.5,12M8.2,12A3.8,3.8 0 0,1 12,8.2A3.8,3.8 0 0,1 15.8,12A3.8,3.8 0 0,1 12,15.8A3.8,3.8 0 0,1 8.2,12M12,10A2,2 0 0,0 10,12A2,2 0 0,0 12,14A2,2 0 0,0 14,12A2,2 0 0,0 12,10Z"/>
                    </svg>
                  ) : (
                    <svg className={`w-10 h-10 ${item.iconColor || 'text-primary-500'}`} fill="currentColor" viewBox="0 0 24 24">
                      <path d={item.icon} />
                  </svg>
                  )}
                </motion.div>
              ))}

              {/* Enhanced Decorative elements */}
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                className="absolute top-0 right-0 w-8 h-8 border-2 border-green-300 rounded-full opacity-60 flex items-center justify-center"
              >
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
              </motion.div>
              <motion.div
                animate={{ 
                  rotate: -360,
                  scale: [1, 1.1, 1]
                }}
                transition={{ 
                  rotate: { duration: 25, repeat: Infinity, ease: "linear" },
                  scale: { duration: 3, repeat: Infinity, ease: "easeInOut" }
                }}
                className="absolute bottom-0 left-0 w-10 h-10 border-2 border-primary-400 rounded-lg opacity-50 flex items-center justify-center bg-primary-50"
              >
                <svg className="w-4 h-4 text-primary-500" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </motion.div>
              
              {/* Additional floating eco-friendly elements */}
              <motion.div
                animate={{ 
                  y: [-10, 10, -10],
                  opacity: [0.3, 0.7, 0.3]
                }}
                transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-1/4 right-0 w-6 h-6 text-green-400 opacity-40"
              >
                <svg fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,13.5C2,15.5 3.75,17.25 3.75,17.25C7,8 17,8 17,8Z"/>
                </svg>
              </motion.div>
              
              <motion.div
                animate={{ 
                  x: [-5, 5, -5],
                  rotate: [0, 180, 360]
                }}
                transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
                className="absolute bottom-1/4 left-0 w-5 h-5 text-blue-400 opacity-50"
              >
                <svg fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12,2A3,3 0 0,1 15,5V11A3,3 0 0,1 12,14A3,3 0 0,1 9,11V5A3,3 0 0,1 12,2M19,11C19,14.53 16.39,17.44 13,17.93V21H11V17.93C7.61,17.44 5,14.53 5,11H7A5,5 0 0,0 12,16A5,5 0 0,0 17,11H19Z"/>
                </svg>
              </motion.div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2"
      >
        <div className="w-6 h-10 border-2 border-primary-400 rounded-full flex justify-center">
          <div className="w-1 h-3 bg-primary-400 rounded-full mt-2"></div>
        </div>
      </motion.div>
    </section>
  )
}

export default Hero 