import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Phone, Calendar, ChevronDown } from 'lucide-react'

const MobileCTA = () => {
  const [isVisible, setIsVisible] = useState(false)
  const [navbarHeight, setNavbarHeight] = useState(64) // Default fallback
  const [lastScrollY, setLastScrollY] = useState(0)

  useEffect(() => {
    const updateNavbarHeight = () => {
      const navbar = document.querySelector('nav') || document.querySelector('[role="navigation"]') || document.querySelector('.navbar')
      if (navbar) {
        const rect = navbar.getBoundingClientRect()
        setNavbarHeight(rect.height)
      }
    }

    // Initial calculation
    updateNavbarHeight()

    // Update on resize and when content changes
    const resizeObserver = new ResizeObserver(updateNavbarHeight)
    const navbar = document.querySelector('nav') || document.querySelector('[role="navigation"]') || document.querySelector('.navbar')
    
    if (navbar) {
      resizeObserver.observe(navbar)
    }

    // Also listen for window resize
    window.addEventListener('resize', updateNavbarHeight)

    // Simplified scroll handler
    const handleScroll = () => {
      const currentScrollY = window.scrollY
      const scrollingUp = currentScrollY < lastScrollY
      const threshold = 300 // Reduced threshold
      
      // Show CTA when scrolled past threshold AND scrolling up
      if (currentScrollY > threshold && scrollingUp) {
        setIsVisible(true)
      } else {
        setIsVisible(false)
      }
      
      setLastScrollY(currentScrollY)
    }

    window.addEventListener('scroll', handleScroll, { passive: true })

    return () => {
      resizeObserver.disconnect()
      window.removeEventListener('resize', updateNavbarHeight)
      window.removeEventListener('scroll', handleScroll)
    }
  }, [lastScrollY])

  const containerVariants = {
    hidden: { 
      opacity: 0, 
      y: -20,
      scale: 0.95
    },
    visible: { 
      opacity: 1, 
      y: 0,
      scale: 1,
      transition: {
        duration: 0.3,
        ease: "easeOut"
      }
    }
  }

  const buttonVariants = {
    hover: { 
      scale: 1.02,
      transition: { duration: 0.2 }
    },
    tap: { 
      scale: 0.98,
      transition: { duration: 0.1 }
    }
  }

  const handleCall = () => {
    window.location.href = 'tel:08007720226'
  }

  const handleBook = () => {
    const contactSection = document.getElementById('contact')
    if (contactSection) {
      contactSection.scrollIntoView({ behavior: 'smooth' })
    }
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          exit="hidden"
          className="fixed left-0 right-0 z-30 md:hidden"
          style={{ top: `${navbarHeight}px` }}
        >
          <div className="bg-white/97 mobile-cta-blur border-b border-primary-200/30 shadow-xl px-4 py-1.5 relative backdrop-blur-md">
            {/* Gradient overlay for enhanced visual appeal */}
            <div className="absolute inset-0 bg-gradient-to-r from-primary-50/50 via-white/30 to-primary-50/50 pointer-events-none"></div>
            
            {/* Background glow effect */}
            <div className="absolute inset-0 bg-gradient-to-r from-primary-100/20 via-transparent to-primary-100/20 blur-sm pointer-events-none"></div>
            
            <div className="flex items-center justify-between gap-3 relative z-10">
              <motion.button
                variants={buttonVariants}
                whileHover="hover"
                whileTap="tap"
                onClick={handleCall}
                className="flex-1 bg-gradient-to-r from-primary-500 via-primary-600 to-primary-500 hover:from-primary-600 hover:via-primary-700 hover:to-primary-600 text-white px-4 py-2 rounded-lg font-semibold text-sm shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2 relative overflow-hidden"
              >
                {/* Button glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/5 to-white/10 pointer-events-none"></div>
                <Phone className="w-4 h-4" />
                <span>Call Us</span>
              </motion.button>
              
              <motion.button
                variants={buttonVariants}
                whileHover="hover"
                whileTap="tap"
                onClick={handleBook}
                className="flex-1 bg-gradient-to-r from-gray-700 via-gray-800 to-gray-700 hover:from-gray-800 hover:via-gray-900 hover:to-gray-800 text-white px-4 py-2 rounded-lg font-semibold text-sm shadow-lg hover:shadow-xl transition-all duration-200 flex items-center justify-center gap-2 relative overflow-hidden"
              >
                {/* Button glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-white/10 via-white/5 to-white/10 pointer-events-none"></div>
                <Calendar className="w-4 h-4" />
                <span>Book Engineer</span>
              </motion.button>
            </div>
            
            {/* Scroll indicator */}
            <motion.div 
              className="flex justify-center mt-1.5"
              animate={{ y: [0, 3, 0] }}
              transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            >
              <ChevronDown className="w-3 h-3 text-primary-400 opacity-60" />
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default MobileCTA 