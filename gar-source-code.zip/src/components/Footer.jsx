import React from 'react'
import { motion } from 'framer-motion'
import { Phone, Mail, MapPin, Star, Heart } from 'lucide-react'
import { Link, useLocation } from 'react-router-dom'

const Footer = () => {
  const location = useLocation()
  
  const footerVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  }

  const currentYear = new Date().getFullYear()

  const quickLinks = [
    { name: 'Home', href: '/' },
    { name: 'Services', href: '#services' },
    { name: 'Sales', href: '/sales' },
    { name: 'About Us', href: '#about' },
    { name: 'Locations', href: '#locations' },
    { name: 'Contact', href: '#contact' }
  ]

  const scrollToSection = (href) => {
    if (href.startsWith('#')) {
      const element = document.querySelector(href)
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' })
      }
    }
  }

  const handleLinkClick = (href) => {
    if (href.startsWith('#')) {
      // If we're not on the home page, navigate to home first
      if (location.pathname !== '/') {
        window.location.href = `/${href}`
      } else {
        scrollToSection(href)
      }
    }
  }

  const services = [
    'Washing Machine Repairs',
    'Tumble Dryer Repairs',
    'Dishwasher Repairs',
    'Electric Oven Repairs',
    'Electric Cooker Repairs',
    'Integrated Appliances'
  ]

  const locations = [
    'Brighton', 'Worthing', 'Haywards Heath',
    'Crawley', 'East Grinstead', 'Horsham',
    'Uckfield', 'Tunbridge Wells'
  ]

  return (
    <footer className="bg-gray-900 text-white">
      <motion.div
        variants={footerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16"
      >
        <div className="grid lg:grid-cols-4 gap-12">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-12 h-12 bg-primary-500 rounded-lg flex items-center justify-center">
                <svg
                  className="w-7 h-7 text-white"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M18 2.01L6 2c-1.11 0-2 .89-2 2v16c0 1.11.89 2 2 2h12c1.11 0 2-.89 2-2V4c0-1.11-.89-1.99-2-1.99zM18 20H6V4h12v16zM8 5h2v2H8V5zm0 3h8v8H8V8z"/>
                </svg>
              </div>
              <div>
                <h3 className="text-xl font-bold">
                  <span className="text-primary-400">Green</span> Appliance Repairs
                </h3>
              </div>
            </div>
            
            <p className="text-gray-300 mb-6 leading-relaxed">
              Family-run business with over 25 years of experience providing reliable appliance repair services across Sussex, Surrey, and Kent.
            </p>

            {/* Key Stats */}
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="text-center p-3 bg-gray-800 rounded-lg">
                <div className="text-2xl font-bold text-primary-400">25+</div>
                <div className="text-xs text-gray-400">Years Experience</div>
              </div>
              <div className="text-center p-3 bg-gray-800 rounded-lg">
                <div className="text-2xl font-bold text-primary-400">10k+</div>
                <div className="text-xs text-gray-400">Happy Customers</div>
              </div>
            </div>

            {/* Contact Highlights */}
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-primary-400" />
                <span className="font-semibold">0800 772 0226</span>
              </div>
              <div className="flex items-center space-x-3">
                <Star className="w-5 h-5 text-yellow-400" />
                <span className="text-sm">Same Day Service Available</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  {link.href.startsWith('/') ? (
                    <Link
                      to={link.href}
                      className="text-gray-300 hover:text-primary-400 transition-colors duration-200 flex items-center group"
                    >
                      <span className="w-0 h-0.5 bg-primary-400 transition-all duration-300 group-hover:w-4 mr-0 group-hover:mr-2"></span>
                      {link.name}
                    </Link>
                  ) : (
                    <button
                      onClick={() => handleLinkClick(link.href)}
                      className="text-gray-300 hover:text-primary-400 transition-colors duration-200 flex items-center group text-left"
                    >
                      <span className="w-0 h-0.5 bg-primary-400 transition-all duration-300 group-hover:w-4 mr-0 group-hover:mr-2"></span>
                      {link.name}
                    </button>
                  )}
                </li>
              ))}
            </ul>

            <div className="mt-8">
              <h5 className="font-semibold mb-4 text-primary-400">Why Choose Us?</h5>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>✓ Fixed rate pricing</li>
                <li>✓ 12 month warranty</li>
                <li>✓ Fully qualified engineers</li>
                <li>✓ Same day service</li>
              </ul>
            </div>
          </div>

          {/* Our Services */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Our Services</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index} className="text-gray-300 text-sm flex items-center">
                  <div className="w-2 h-2 bg-primary-400 rounded-full mr-3 flex-shrink-0"></div>
                  {service}
                </li>
              ))}
            </ul>

            <div className="mt-8 p-4 bg-primary-900 rounded-lg border border-primary-700">
              <h5 className="font-semibold mb-2 text-primary-300">Pricing</h5>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-300">Freestanding:</span>
                  <span className="text-white font-semibold">£65-£85</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-300">Integrated:</span>
                  <span className="text-white font-semibold">£85-£105</span>
                </div>
              </div>
            </div>
          </div>

          {/* Locations & Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-6">Service Locations</h4>
            <div className="grid grid-cols-2 gap-2 mb-8">
              {locations.map((location, index) => (
                <div key={index} className="text-sm text-gray-300 flex items-center">
                  <MapPin className="w-3 h-3 text-primary-400 mr-2 flex-shrink-0" />
                  {location}
                </div>
              ))}
            </div>

            <div className="space-y-4">
              <h5 className="font-semibold text-primary-400">Get in Touch</h5>
              
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <Phone className="w-5 h-5 text-primary-400 mt-0.5" />
                  <div>
                    <div className="font-semibold">Call Free</div>
                    <div className="text-xl font-bold text-primary-400">0800 772 0226</div>
                  </div>
                </div>
                
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-primary-400" />
                  <div className="text-sm text-gray-300">info@greenappliancerepairs.co.uk</div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-primary-400 mt-0.5" />
                  <div className="text-sm text-gray-300">
                    Serving Sussex, Surrey & Kent<br />
                    and surrounding areas
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4 text-sm text-gray-400">
              <span>© {currentYear} Green Appliance Repairs. All Rights Reserved.</span>
            </div>
            
            <div className="flex items-center space-x-6 text-sm text-gray-400">
              <a href="#" className="hover:text-primary-400 transition-colors duration-200">Privacy Policy</a>
              <a href="#" className="hover:text-primary-400 transition-colors duration-200">Cookie Policy</a>
              <a href="#" className="hover:text-primary-400 transition-colors duration-200">Terms of Service</a>
            </div>
          </div>
          
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-400 flex items-center justify-center">
              Made with <Heart className="w-4 h-4 text-red-500 mx-1" /> for a family business
            </p>
          </div>
        </div>
      </motion.div>
    </footer>
  )
}

export default Footer 