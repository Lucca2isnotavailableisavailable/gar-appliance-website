import React from 'react'
import { motion } from 'framer-motion'

const BackgroundElements = () => {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-primary-100 animate-gradient" />
      
      {/* Texture overlay */}
      <div className="absolute inset-0 bg-texture opacity-30" />
      
      {/* Floating particles */}
      {[...Array(20)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-2 h-2 bg-primary-300 rounded-full opacity-20"
          animate={{
            x: [0, 100, 0],
            y: [0, -100, 0],
          }}
          transition={{
            duration: 10 + i * 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
        />
      ))}
      
      {/* Large geometric shapes */}
      <motion.div
        className="absolute top-20 right-20 w-32 h-32 border border-primary-200 rounded-full opacity-30"
        animate={{ rotate: 360 }}
        transition={{ duration: 30, repeat: Infinity, ease: "linear" }}
      />
      
      <motion.div
        className="absolute bottom-20 left-20 w-24 h-24 bg-primary-100 rounded-lg opacity-40"
        animate={{ 
          scale: [1, 1.2, 1],
          rotate: [0, 180, 360]
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "easeInOut" }}
      />
      
      {/* Appliance-themed background icons */}
      <div className="absolute inset-0 opacity-5">
        {/* Washing machine outline */}
        <motion.svg
          className="absolute top-1/4 left-1/4 w-16 h-16 text-primary-600"
          animate={{ rotate: [0, 10, 0] }}
          transition={{ duration: 8, repeat: Infinity }}
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M18 2.01L6 2c-1.11 0-2 .89-2 2v16c0 1.11.89 2 2 2h12c1.11 0 2-.89 2-2V4c0-1.11-.89-1.99-2-1.99zM18 20H6V4h12v16zM8 5h2v2H8V5zm0 3h8v8H8V8z"/>
        </motion.svg>
        
        {/* Dryer outline */}
        <motion.svg
          className="absolute top-3/4 right-1/4 w-12 h-12 text-primary-600"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 6, repeat: Infinity }}
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 18H6V4h12v16zM12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm0 10c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z"/>
        </motion.svg>
      </div>
    </div>
  )
}

export default BackgroundElements 