import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Phone } from 'lucide-react'
import { Link } from 'react-router-dom'

// Custom Logo Component with Enhanced SVG
const GreenApplianceLogo = ({ className = "w-8 h-8" }) => (
  <svg
    viewBox="0 0 500 500"
    className={className}
    fill="currentColor"
  >
    <defs>
      <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#10B981" />
        <stop offset="50%" stopColor="#059669" />
        <stop offset="100%" stopColor="#047857" />
      </linearGradient>
    </defs>
    <g transform="matrix(0.961733, 0, 0, 0.908641, -28.350359, 263.023438)">
      <g transform="matrix(1, 0, 0, 1, 35.372852, 14.210501)">
        <path
          fill="url(#logoGradient)"
          d="M 312.637 21.198 C 266.083 1.468 207.78 20.311 188.272 69.303 L 188.272 69.525 L 188.272 69.747 C 174.749 106.325 191.597 139.799 216.426 153.765 C 228.84 160.859 243.693 163.297 257.437 158.642 C 265.418 155.982 272.512 150.883 278.497 143.789 C 287.808 143.567 296.675 138.69 301.552 130.045 L 315.74 105.66 L 309.976 102.334 L 320.839 83.713 C 322.391 80.831 321.504 77.284 318.622 75.511 C 315.74 73.959 312.193 74.845 310.42 77.727 L 299.557 96.349 L 284.039 87.26 L 294.902 68.638 C 296.454 65.756 295.567 62.21 292.685 60.436 C 289.803 58.884 286.256 59.771 284.483 62.653 L 273.62 81.274 L 268.078 77.949 L 253.89 102.334 C 247.683 112.975 249.457 125.833 257.216 134.478 C 254.999 136.252 252.782 137.36 250.343 138.025 C 243.25 140.464 234.826 139.355 226.623 134.7 C 210.662 125.611 198.026 104.329 208.002 77.062 C 222.855 40.263 268.078 25.853 303.991 40.928 C 349.436 60.214 367.171 116.3 347.441 160.859 C 323.277 215.393 255.886 236.231 202.46 211.846 C 138.615 182.805 114.451 103.221 143.714 40.706 C 156.35 13.882 177.631 -8.951 204.012 -23.139 C 290.69 -69.914 306.651 -155.04 270.295 -217.78 C 253.89 -245.93 227.732 -273.64 196.031 -300.69 C 223.298 -229.31 81.864 -156.15 171.646 -49.076 C 225.071 -80.998 239.259 -126.89 236.599 -179.65 C 246.575 -141.74 237.486 -98.068 217.313 -67.475 C 200.021 -41.76 172.311 -30.454 153.024 -10.059 C 141.497 2.133 131.743 16.321 124.649 31.617 C 90.509 104.551 118.663 196.993 194.036 231.354 C 257.881 260.395 338.352 235.566 367.614 169.504 C 382.91 135.143 380.028 95.24 361.629 64.205 C 350.766 45.805 334.14 30.287 312.637 21.198 Z"
        />
      </g>
    </g>
  </svg>
)

// Recycling Icon Component
const RecyclingIcon = ({ className = "w-5 h-5" }) => (
  <svg
    viewBox="0 0 24 24"
    className={className}
    fill="currentColor"
  >
    <defs>
      <linearGradient id="recycleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#10B981" />
        <stop offset="100%" stopColor="#059669" />
      </linearGradient>
    </defs>
    <path
      fill="url(#recycleGradient)"
      d="M12 2L13.09 8.26L19 7L17.74 12.74L23 14.27L17.65 18.15L19.74 23.5L14 19.5L8.26 23.5L10.35 18.15L5 14.27L10.26 12.74L9 7L14.91 8.26L12 2Z"
    />
    <path
      fill="url(#recycleGradient)"
      d="M8.5 12.5L12 9L15.5 12.5L12 16L8.5 12.5Z"
      opacity="0.8"
    />
  </svg>
)

// Eco-Friendly Badge Component
const EcoBadge = ({ className = "w-4 h-4" }) => (
  <svg
    viewBox="0 0 24 24"
    className={className}
    fill="currentColor"
  >
    <defs>
      <linearGradient id="ecoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#34D399" />
        <stop offset="100%" stopColor="#10B981" />
      </linearGradient>
    </defs>
    <path
      fill="url(#ecoGradient)"
      d="M17,8C8,10 5.9,16.17 3.82,21.34L5.71,22L6.66,19.7C7.14,19.87 7.64,20 8,20C19,20 22,3 22,3C21,5 14,5.25 9,6.25C4,7.25 2,11.5 2,11.5C2,11.5 3,9 7,8.75C11,8.5 17,8 17,8Z"
    />
  </svg>
)

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navItems = [
    { name: 'Home', href: '/' },
    { name: 'Services', href: '#services' },
    { name: 'Sales', href: '/sales' },
    { name: 'About', href: '#about' },
    { name: 'Locations', href: '#locations' },
    { name: 'Contact', href: '#contact' },
  ]

  const scrollToSection = (href) => {
    if (href.startsWith('#')) {
      const element = document.querySelector(href)
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' })
      }
    }
  }

  const handleNavClick = (href) => {
    setIsOpen(false)
    if (href.startsWith('#')) {
      scrollToSection(href)
    }
  }

  return (
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled 
          ? 'bg-white/40 backdrop-blur-xl shadow-lg border-b border-white/20' 
          : 'bg-white/25 backdrop-blur-lg'
      }`}
    >
      {/* Top eco-friendly banner */}
      <div className="bg-gradient-to-r from-green-500 via-primary-500 to-green-600 text-white text-center py-0.5 md:py-1 text-xs font-medium relative overflow-hidden">
        {/* Subtle background pattern */}
        <div className="absolute inset-0 bg-gradient-to-r from-green-400/20 via-transparent to-primary-400/20"></div>
        
        <div className="flex items-center justify-center space-x-2 relative z-10">
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          >
            <EcoBadge className="w-3 h-3" />
          </motion.div>
          <span className="font-semibold tracking-wide">🌱 Eco-Friendly Appliance Repairs Since 1999</span>
          <motion.div
            animate={{ rotate: [360, 0] }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          >
            <RecyclingIcon className="w-3 h-3" />
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Enhanced Logo Section */}
          <motion.div
            whileHover={{ scale: 1.02 }}
            className="flex items-center space-x-3"
          >
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-primary-400 to-primary-600 rounded-xl blur opacity-30 group-hover:opacity-50 transition-opacity duration-300"></div>
              <div className="relative w-14 h-14 bg-gradient-to-br from-white to-gray-50 rounded-xl flex items-center justify-center shadow-lg border border-white/20">
                <GreenApplianceLogo className="w-8 h-8 text-primary-600" />
              </div>
              {/* Floating eco badges */}
              <div className="absolute -top-1 -right-1 bg-green-500 rounded-full p-1">
                <EcoBadge className="w-3 h-3 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 leading-tight">
                <span className="bg-gradient-to-r from-primary-600 to-primary-500 bg-clip-text text-transparent">Green</span>{' '}
                Appliance Repairs
              </h1>
              <div className="flex items-center justify-between text-xs text-gray-600 font-medium w-full max-w-[180px]">
                <span>Professional</span>
                <span>•</span>
                <span>Reliable</span>
                <span>•</span>
                <span>Eco</span>
              </div>
            </div>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center space-x-8">
            {navItems.map((item) => (
              <div key={item.name} className="relative">
                {item.href.startsWith('/') ? (
                  <Link
                    to={item.href}
                    className="text-gray-700 hover:text-primary-600 font-medium py-2 px-1 transition-colors duration-200 relative group"
                  >
                    {item.name}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-500 transition-all duration-300 group-hover:w-full rounded-full" />
                  </Link>
                ) : (
                  <button
                    onClick={() => scrollToSection(item.href)}
                    className="text-gray-700 hover:text-primary-600 font-medium py-2 px-1 transition-colors duration-200 relative group"
                  >
                    {item.name}
                    <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary-500 transition-all duration-300 group-hover:w-full rounded-full" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Clean Desktop CTA Section */}
          <div className="hidden lg:flex items-center space-x-3">
            <motion.a
              href="tel:08007720226"
              whileHover={{ scale: 1.02 }}
              className="flex items-center space-x-2 text-gray-700 hover:text-primary-600 transition-colors duration-200 font-medium bg-white/60 backdrop-blur-sm rounded-lg px-4 py-2.5 border border-white/30"
            >
              <Phone className="w-4 h-4" />
              <span>0800 772 0226</span>
            </motion.a>

            <motion.button
              whileHover={{ 
                scale: 1.05,
                boxShadow: "0 8px 25px rgba(16, 185, 129, 0.25)"
              }}
              whileTap={{ scale: 0.95 }}
              onClick={() => scrollToSection('#contact')}
              className="bg-primary-600 hover:bg-primary-700 text-white px-6 py-2.5 rounded-lg font-semibold transition-all duration-200 shadow-lg"
            >
              Book Engineer
            </motion.button>
          </div>

          {/* Fixed Mobile Menu Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setIsOpen(!isOpen)}
            className="lg:hidden p-3 rounded-lg text-gray-700 hover:text-primary-600 hover:bg-white/30 transition-all duration-200 bg-white/50 backdrop-blur-sm border border-white/30"
          >
            <AnimatePresence mode="wait">
              {isOpen ? (
                <motion.div
                  key="close"
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <X className="w-6 h-6" />
                </motion.div>
              ) : (
                <motion.div
                  key="menu"
                  initial={{ rotate: 90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: -90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  <Menu className="w-6 h-6" />
                </motion.div>
              )}
            </AnimatePresence>
          </motion.button>
        </div>

        {/* Fixed Mobile Menu */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              className="lg:hidden overflow-hidden bg-white/90 backdrop-blur-md border-t border-white/30 mt-1 rounded-b-xl shadow-xl"
            >
              <div className="py-4 space-y-1">
                {navItems.map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ x: -20, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.05 }}
                  >
                    {item.href.startsWith('/') ? (
                      <Link
                        to={item.href}
                        onClick={() => handleNavClick(item.href)}
                        className="block px-4 py-3 text-gray-700 hover:text-primary-600 hover:bg-white/40 rounded-lg transition-colors duration-200 mx-2 font-medium"
                      >
                        {item.name}
                      </Link>
                    ) : (
                      <button
                        onClick={() => handleNavClick(item.href)}
                        className="block w-full text-left px-4 py-3 text-gray-700 hover:text-primary-600 hover:bg-white/40 rounded-lg transition-colors duration-200 mx-2 font-medium"
                      >
                        {item.name}
                      </button>
                    )}
                  </motion.div>
                ))}
                
                {/* Mobile CTA Section */}
                <motion.div
                  initial={{ y: 10, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: navItems.length * 0.05 }}
                  className="pt-4 border-t border-white/30 mx-2 space-y-3"
                >
                  <a
                    href="tel:08007720226"
                    className="flex items-center space-x-2 px-4 py-3 text-gray-700 hover:text-primary-600 transition-colors duration-200 bg-white/50 rounded-lg"
                  >
                    <Phone className="w-4 h-4" />
                    <span className="font-medium">Call 0800 772 0226</span>
                  </a>
                  <button 
                    onClick={() => handleNavClick('#contact')}
                    className="w-full mx-0 bg-primary-600 hover:bg-primary-700 text-white py-3 rounded-lg font-semibold transition-all duration-200 shadow-lg"
                  >
                    Book Engineer
                  </button>
                </motion.div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  )
}

export default Navbar 