import React from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Star, Quote } from 'lucide-react'

const Testimonials = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const testimonials = [
    {
      name: "Mrs Peters",
      location: "Lindfield",
      rating: 5,
      review: "Receptionist very knowledgable and friendly, engineers time keeping excellent, from start to finish an excellent service.",
      service: "Washing Machine Repair"
    },
    {
      name: "M Green",
      location: "Henfield",
      rating: 5,
      review: "Engineer repaired my cooker. Came out same day, was polite and efficient. Highly recommend.",
      service: "Electric Cooker Repair"
    },
    {
      name: "C Kelly",
      location: "Albourne",
      rating: 5,
      review: "Engineer inspected our dishwasher which could not be repaired. We purchased a new one from Green Appliance Repairs which arrived the following day, very fast service.",
      service: "Dishwasher Service & Sale"
    },
    {
      name: "Mr Nicholas",
      location: "Brighton",
      rating: 5,
      review: "Green Appliance Repairs repaired washing machine, fast service, nice company. Will use again.",
      service: "Washing Machine Repair"
    },
    {
      name: "G Gilbert",
      location: "East Grinstead",
      rating: 5,
      review: "Washing Machine repair, engineer attended same day, had to order part, was back the next day as promised and completed job. 10/10.",
      service: "Washing Machine Repair"
    },
    {
      name: "M Sharp",
      location: "Haywards Heath",
      rating: 5,
      review: "Engineer repaired tumble dryer, excellent service.",
      service: "Tumble Dryer Repair"
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  }

  const itemVariants = {
    hidden: { y: 30, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  }

  return (
    <section id="testimonials" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.h2
              variants={itemVariants}
              className="text-3xl md:text-4xl font-bold text-gray-900 mb-6"
            >
              What Our <span className="gradient-text">Customers Say</span>
            </motion.h2>
            <motion.p
              variants={itemVariants}
              className="text-xl text-gray-600 max-w-3xl mx-auto"
            >
              Don't just take our word for it. Here's what our satisfied customers have to say about our appliance repair services.
            </motion.p>
          </div>

          {/* Featured Stats */}
          <motion.div
            variants={itemVariants}
            className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16"
          >
            {[
              { stat: "4.9/5", label: "Average Rating", icon: Star },
              { stat: "10,000+", label: "Happy Customers", icon: Star },
              { stat: "98%", label: "Same Day Success", icon: Star },
              { stat: "100%", label: "Would Recommend", icon: Star }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <item.icon className="w-8 h-8 text-primary-600" />
                </div>
                <div className="text-3xl font-bold text-primary-600 mb-2">{item.stat}</div>
                <div className="text-sm font-medium text-gray-600">{item.label}</div>
              </div>
            ))}
          </motion.div>

          {/* Testimonials Grid */}
          <motion.div
            variants={containerVariants}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                variants={itemVariants}
                whileHover={{ scale: 1.02 }}
                className="bg-gray-50 rounded-2xl p-8 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300"
              >
                {/* Quote Icon */}
                <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mb-6">
                  <Quote className="w-6 h-6 text-primary-600" />
                </div>

                {/* Star Rating */}
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>

                {/* Review Text */}
                <blockquote className="text-gray-700 mb-6 leading-relaxed">
                  "{testimonial.review}"
                </blockquote>

                {/* Service Type */}
                <div className="inline-flex items-center bg-primary-100 text-primary-700 px-3 py-1 rounded-full text-sm font-medium mb-4">
                  {testimonial.service}
                </div>

                {/* Customer Info */}
                <div className="border-t border-gray-200 pt-4">
                  <div className="font-semibold text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-500">{testimonial.location}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>

          {/* Trust Indicators */}
          <motion.div
            variants={itemVariants}
            className="mt-16 bg-gradient-to-r from-primary-500 to-primary-600 rounded-2xl p-8 md:p-12 text-center text-white"
          >
            <h3 className="text-2xl md:text-3xl font-bold mb-4">
              Join Thousands of Satisfied Customers
            </h3>
            <p className="text-xl mb-8 opacity-90">
              Experience the quality service that has made us Sussex's trusted appliance repair specialists
            </p>
            
            <div className="grid md:grid-cols-3 gap-6 mb-8">
              {[
                "Over 25 years experience",
                "Same day service available", 
                "12 month warranty on parts"
              ].map((feature, index) => (
                <div key={index} className="flex items-center justify-center space-x-2">
                  <Star className="w-5 h-5" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-white text-primary-600 font-semibold py-3 px-8 rounded-lg hover:bg-gray-50 transition-colors duration-300"
              >
                Read More Reviews
              </motion.button>
              <motion.a
                href="#contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="border-2 border-white text-white font-semibold py-3 px-8 rounded-lg hover:bg-white hover:text-primary-600 transition-all duration-300 inline-block"
              >
                Book Your Repair
              </motion.a>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

export default Testimonials 