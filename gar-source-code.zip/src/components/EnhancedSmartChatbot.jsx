import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  Bot, 
  Minimize2, 
  X, 
  Send, 
  Phone, 
  User, 
  Sparkles,
  Wrench,
  Droplets,
  Wind,
  Thermometer
} from 'lucide-react'
import ContactFormModal from './ContactFormModal'

const EnhancedSmartChatbot = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState([])
  const [currentInput, setCurrentInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const [currentStep, setCurrentStep] = useState('welcome')
  const [selectedAppliance, setSelectedAppliance] = useState(null)
  const [selectedFault, setSelectedFault] = useState(null)
  const [applianceType, setApplianceType] = useState(null)
  const [showContactForm, setShowContactForm] = useState(false)
  const [hasNewMessage, setHasNewMessage] = useState(false)
  const [hasAutoOpened, setHasAutoOpened] = useState(false)
  const [minimizedAt, setMinimizedAt] = useState(null)
  const messagesEndRef = useRef(null)
  const chatRef = useRef(null)

  const appliances = {
    washingMachine: {
      name: 'Washing Machine',
      icon: 'Wrench',
      color: 'from-blue-500 to-blue-600',
      faults: [
        'Not spinning or draining',
        'Not heating water',
        'Excessive noise or vibration',
        'Door won\'t open/close',
        'Water leaking',
        'Not starting or no power'
      ]
    },
    tumbleDryer: {
      name: 'Tumble Dryer',
      icon: 'Wind',
      color: 'from-orange-500 to-orange-600',
      faults: [
        'Not heating',
        'Not drying clothes properly',
        'Excessive noise',
        'Door won\'t stay closed',
        'Not tumbling',
        'Overheating or burning smell'
      ]
    },
    dishwasher: {
      name: 'Dishwasher',
      icon: 'Droplets',
      color: 'from-teal-500 to-teal-600',
      faults: [
        'Not cleaning dishes properly',
        'Not draining water',
        'Not filling with water',
        'Door seal leaking',
        'Strange noises',
        'Not starting cycle'
      ]
    },
    oven: {
      name: 'Oven',
      icon: 'Thermometer',
      color: 'from-red-500 to-red-600',
      faults: [
        'Not heating to correct temperature',
        'Oven door won\'t close properly',
        'Fan not working',
        'Grill element not working',
        'Timer or controls not working',
        'Strange smells or smoke'
      ]
    }
  }

  const iconComponents = {
    Wrench,
    Wind,
    Droplets,
    Thermometer
  }

  const quickReplies = [
    'Book a repair',
    'Get a quote',
    'Emergency repair',
    'Warranty claim'
  ]

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      startConversation()
    }
  }, [isOpen])

  // Auto-popup functionality
  useEffect(() => {
    const autoOpenTimer = setTimeout(() => {
      if (!hasAutoOpened && !isOpen) {
        // Check if it was minimized recently (within 2 minutes)
        const now = Date.now()
        const twoMinutes = 2 * 60 * 1000 // 2 minutes in milliseconds
        
        if (!minimizedAt || (now - minimizedAt) > twoMinutes) {
          playNotificationSound()
          setIsOpen(true)
          setHasAutoOpened(true)
          setHasNewMessage(true)
        }
      }
    }, 8000) // 8 seconds

    return () => clearTimeout(autoOpenTimer)
  }, [hasAutoOpened, isOpen, minimizedAt])

  // Play notification sound
  const playNotificationSound = () => {
    try {
      // Create a simple notification beep using Web Audio API
      const audioContext = new (window.AudioContext || window.webkitAudioContext)()
      const oscillator = audioContext.createOscillator()
      const gainNode = audioContext.createGain()
      
      oscillator.connect(gainNode)
      gainNode.connect(audioContext.destination)
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime) // 800 Hz tone
      oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1) // Drop to 600 Hz
      
      gainNode.gain.setValueAtTime(0, audioContext.currentTime)
      gainNode.gain.linearRampToValueAtTime(0.3, audioContext.currentTime + 0.01)
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3)
      
      oscillator.start(audioContext.currentTime)
      oscillator.stop(audioContext.currentTime + 0.3)
    } catch (error) {
      console.log('Audio notification not available:', error)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const startConversation = () => {
    setTimeout(() => {
      addBotMessage(
        "Hello! I'm your Smart Repair Assistant. I'm here to help you get your appliance fixed quickly. Which appliance needs attention?",
        true
      )
      setCurrentStep('selectAppliance')
    }, 500)
  }

  const addBotMessage = (content, showQuickReplies = false) => {
    const message = {
      id: Date.now(),
      type: 'bot',
      content,
      timestamp: new Date(),
      showQuickReplies
    }
    setMessages(prev => [...prev, message])
    if (!isOpen) {
      setHasNewMessage(true)
    }
  }

  const addUserMessage = (content) => {
    const message = {
      id: Date.now(),
      type: 'user',
      content,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, message])
  }

  const handleApplianceSelect = (key) => {
    setSelectedAppliance(key)
    const appliance = appliances[key]
    addUserMessage(appliance.name)
    
    // Check if this appliance type needs installation type question
    const needsInstallationType = ['washingMachine', 'tumbleDryer', 'dishwasher'].includes(key)
    
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      if (needsInstallationType) {
        addBotMessage(`Perfect! Is your ${appliance.name.toLowerCase()} integrated (built-in) or freestanding?`)
        setCurrentStep('selectType')
      } else {
        addBotMessage(`Great choice! What specific issue are you experiencing with your ${appliance.name.toLowerCase()}?`)
        setCurrentStep('selectFault')
      }
    }, 1000)
  }

  const handleApplianceTypeSelect = (type) => {
    setApplianceType(type)
    addUserMessage(type)
    
    const appliance = appliances[selectedAppliance]
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      addBotMessage(`Thanks! What specific issue are you experiencing with your ${type.toLowerCase()} ${appliance.name.toLowerCase()}?`)
      setCurrentStep('selectFault')
    }, 1000)
  }

  const handleFaultSelect = (fault) => {
    setSelectedFault(fault)
    addUserMessage(fault)
    
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      addBotMessage(
        `I understand you're having issues with "${fault.toLowerCase()}". To provide you with the best service, I'll need some contact details. Our engineers can typically resolve this type of issue and provide same-day service.`
      )
      setCurrentStep('collectInfo')
    }, 1200)
  }

  const handleQuickReply = (reply) => {
    addUserMessage(reply)
    
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      if (reply.includes('Book') || reply.includes('Emergency')) {
        addBotMessage("I'll help you book a repair. First, which appliance needs fixing?")
        setCurrentStep('selectAppliance')
      } else if (reply.includes('quote')) {
        addBotMessage("I can provide you with pricing information. Our fixed rates are £65-£85 for freestanding appliances and £85-£105 for integrated units. Which appliance do you need a quote for?")
        setCurrentStep('selectAppliance')
      } else if (reply.includes('Warranty')) {
        addBotMessage("I'll help you with your warranty claim. All our repairs come with a 12-month warranty on parts. Which appliance is this regarding?")
        setCurrentStep('selectAppliance')
      }
    }, 800)
  }

  const handleSendMessage = () => {
    if (!currentInput.trim()) return
    
    const userMessage = currentInput.trim()
    addUserMessage(userMessage)
    setCurrentInput('')
    
    setIsTyping(true)
    setTimeout(() => {
      setIsTyping(false)
      
      if (userMessage.toLowerCase().includes('hello') || userMessage.toLowerCase().includes('hi')) {
        addBotMessage("Hello! I'm here to help with your appliance repairs. Which appliance needs attention?", true)
        setCurrentStep('selectAppliance')
      } else if (userMessage.toLowerCase().includes('price') || userMessage.toLowerCase().includes('cost')) {
        addBotMessage("Our transparent pricing: £65-£85 for freestanding appliances, £85-£105 for integrated units. This includes diagnosis, labor, and parts. Which appliance needs repair?")
        setCurrentStep('selectAppliance')
      } else if (userMessage.toLowerCase().includes('thank')) {
        addBotMessage("You're very welcome! Don't hesitate to reach out if you need any more help. Have a great day!")
      } else {
        addBotMessage("I understand. Let me help you get the right assistance. Which appliance would you like help with?", true)
        setCurrentStep('selectAppliance')
      }
    }, 1000)
  }

  const handleContactFormSuccess = (bookingId, emailSent) => {
    setShowContactForm(false)
    setIsTyping(true)
    
    setTimeout(() => {
      setIsTyping(false)
      addBotMessage(
        `Perfect! Your booking has been confirmed with reference ${bookingId}. A confirmation email has been sent to you. Our engineer will contact you within 2 hours to arrange the visit. Is there anything else I can help you with?`
      )
      setCurrentStep('completed')
    }, 1000)
  }

  const toggleChat = () => {
    if (isOpen) {
      // If closing the chat, record the time for minimize delay
      setMinimizedAt(Date.now())
    }
    setIsOpen(!isOpen)
    setIsMinimized(false)
    if (!isOpen) {
      setHasNewMessage(false)
    }
  }

  const minimizeChat = () => {
    if (!isMinimized) {
      // Record the time when minimizing
      setMinimizedAt(Date.now())
    }
    setIsMinimized(!isMinimized)
  }

  const resetConversation = () => {
    setMessages([])
    setCurrentStep('welcome')
    setSelectedAppliance(null)
    setSelectedFault(null)
    setApplianceType(null)
    setCurrentInput('')
    startConversation()
  }

      return (
    <>
      <div className="fixed bottom-4 right-4 sm:bottom-6 sm:right-6 z-50">
        {/* Chat Toggle Button */}
        <AnimatePresence>
          {!isOpen && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="relative"
            >
                              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={toggleChat}
                className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-full p-3 sm:p-4 shadow-2xl flex items-center gap-2 sm:gap-3 group transition-all duration-300 text-sm sm:text-base"
                initial={hasAutoOpened ? { scale: 0, rotate: -180 } : { scale: 1 }}
                animate={hasAutoOpened ? { 
                  scale: [0, 1.2, 1], 
                  rotate: [180, 0, 0],
                  boxShadow: [
                    "0 0 0 0 rgba(34, 197, 94, 0.7)",
                    "0 0 0 20px rgba(34, 197, 94, 0)",
                    "0 0 0 0 rgba(34, 197, 94, 0)"
                  ]
                } : {}}
                transition={hasAutoOpened ? { 
                  duration: 1.5, 
                  ease: "backOut",
                  boxShadow: { duration: 2, repeat: 2 }
                } : {}}
              >
                <div className="w-10 h-10 rounded-full flex items-center justify-center overflow-hidden border-2 border-white shadow-lg">
                  <img 
                    src="/images/gar2.jpg" 
                    alt="Green Appliance Repairs Assistant" 
                    className="w-full h-full object-cover rounded-full"
                    onError={(e) => {
                      e.target.style.display = 'none';
                      e.target.nextSibling.style.display = 'flex';
                    }}
                  />
                  <div className="w-full h-full bg-white/20 rounded-full flex items-center justify-center" style={{display: 'none'}}>
                    <Bot className="w-6 h-6" />
                  </div>
                </div>
                <div>
                  <div className="font-semibold hidden sm:block">Smart Repair Assistant</div>
                  <div className="font-semibold sm:hidden text-xs">Assistant</div>
                  <div className="text-xs sm:text-sm opacity-90 hidden sm:block">Get instant help</div>
                </div>
                <div className="w-3 h-3 bg-green-300 rounded-full animate-pulse"></div>
              </motion.button>

              {hasNewMessage && (
                <motion.div
                  initial={{ opacity: 0, x: 20, y: 10 }}
                  animate={{ opacity: 1, x: 0, y: 0 }}
                  className="absolute bottom-full right-0 mb-2 bg-white rounded-lg shadow-lg p-3 max-w-xs border border-gray-200"
                >
                  <div className="flex items-center gap-2 mb-1">
                    <div className="w-4 h-4 rounded-full overflow-hidden border border-green-200 shadow-sm">
                      <img 
                        src="/images/gar2.jpg" 
                        alt="Green Appliance Repairs Assistant" 
                        className="w-full h-full object-cover rounded-full"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.nextSibling.style.display = 'block';
                        }}
                      />
                      <Bot className="w-4 h-4 text-green-500" style={{display: 'none'}} />
                    </div>
                    <span className="font-semibold text-xs text-gray-700">Repair Assistant</span>
                    {hasAutoOpened && (
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">
                    {hasAutoOpened 
                      ? "Hi! I noticed you're browsing our repair services. Need help with an appliance?" 
                      : "Hi! Need help with an appliance? I'm here to assist!"
                    }
                  </p>
                  <div className="absolute bottom-0 right-4 w-0 h-0 border-l-4 border-l-transparent border-r-4 border-r-transparent border-t-4 border-t-white"></div>
                </motion.div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Chat Window */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              ref={chatRef}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ 
                opacity: 1, 
                scale: 1, 
                y: 0,
                height: isMinimized ? '60px' : 'auto'
              }}
              exit={{ opacity: 0, scale: 0.8, y: 20 }}
              className="bg-white rounded-2xl shadow-2xl w-96 max-w-[calc(100vw-2rem)] max-h-[calc(100vh-2rem)] sm:w-96 sm:max-h-[600px] flex flex-col overflow-hidden border border-gray-200 transition-all duration-300 md:fixed md:bottom-6 md:right-6 fixed bottom-0 right-0 left-0 sm:left-auto sm:rounded-2xl rounded-t-2xl rounded-b-none sm:rounded-b-2xl"
            >
              {/* Chat Header */}
              <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center overflow-hidden border-2 border-white shadow-lg">
                    <img 
                      src="/images/gar2.jpg" 
                      alt="Green Appliance Repairs Assistant" 
                      className="w-full h-full object-cover rounded-full"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.nextSibling.style.display = 'flex';
                      }}
                    />
                    <div className="w-full h-full bg-white/20 rounded-full flex items-center justify-center" style={{display: 'none'}}>
                      <Bot className="w-6 h-6" />
                    </div>
                  </div>
                  <div>
                    <h3 className="font-semibold">Smart Repair Assistant</h3>
                    <div className="flex items-center gap-1 text-green-100 text-sm">
                      <div className="w-2 h-2 bg-green-300 rounded-full animate-pulse"></div>
                      <span>Online • Avg response: 30s</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={minimizeChat}
                    className="p-1 hover:bg-white/20 rounded-full transition-colors"
                  >
                    <Minimize2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={toggleChat}
                    className="p-1 hover:bg-white/20 rounded-full transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Messages Area */}
              {!isMinimized && (
                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-gray-50 to-white min-h-[300px] max-h-[calc(100vh-300px)] sm:max-h-[400px]">
                  {messages.map((message) => (
                    <motion.div
                      key={message.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`flex items-end gap-2 max-w-[85%] ${
                        message.type === 'user' ? 'flex-row-reverse' : 'flex-row'
                      }`}>
                        {message.type === 'bot' && (
                          <div className="w-8 h-8 rounded-full flex items-center justify-center mb-1 shadow-lg overflow-hidden border-2 border-white">
                            <img 
                              src="/images/gar2.jpg" 
                              alt="Green Appliance Repairs Assistant" 
                              className="w-full h-full object-cover rounded-full"
                              onError={(e) => {
                                e.target.style.display = 'none';
                                e.target.nextSibling.style.display = 'flex';
                              }}
                            />
                            <div className="w-full h-full bg-green-500 rounded-full flex items-center justify-center" style={{display: 'none'}}>
                              <Bot className="w-4 h-4 text-white" />
                            </div>
                          </div>
                        )}
                        <div className={`px-4 py-3 rounded-2xl shadow-sm ${
                          message.type === 'user' 
                            ? 'bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-br-md' 
                            : 'bg-white border border-gray-200 rounded-bl-md'
                        }`}>
                          <p className="text-sm whitespace-pre-line">{message.content}</p>
                          <div className="text-xs opacity-70 mt-1">
                            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}

                  {/* Typing Indicator */}
                  {isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex justify-start"
                    >
                      <div className="flex items-end gap-2">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center overflow-hidden border-2 border-white shadow-lg">
                          <img 
                            src="/images/gar2.jpg" 
                            alt="Green Appliance Repairs Assistant" 
                            className="w-full h-full object-cover rounded-full"
                            onError={(e) => {
                              e.target.style.display = 'none';
                              e.target.nextSibling.style.display = 'flex';
                            }}
                          />
                          <div className="w-full h-full bg-green-500 rounded-full flex items-center justify-center" style={{display: 'none'}}>
                            <Bot className="w-4 h-4 text-white" />
                          </div>
                        </div>
                        <div className="bg-white border border-gray-200 rounded-2xl rounded-bl-md px-4 py-3 shadow-sm">
                          <div className="flex gap-1">
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                            <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  )}

                  {/* Quick Replies */}
                  {messages.length > 0 && messages[messages.length - 1]?.showQuickReplies && !isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex flex-wrap gap-2 mt-4"
                    >
                      {quickReplies.map((reply, index) => (
                        <motion.button
                          key={index}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => handleQuickReply(reply)}
                          className="text-xs px-3 py-2 border border-green-200 rounded-full hover:bg-green-50 hover:border-green-300 transition-all duration-200 text-green-700 font-medium"
                        >
                          {reply}
                        </motion.button>
                      ))}
                    </motion.div>
                  )}

                  {/* Appliance Selection */}
                  {currentStep === 'selectAppliance' && !isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="grid grid-cols-2 gap-3 mt-4"
                    >
                      {Object.entries(appliances).map(([key, appliance]) => {
                        const IconComponent = iconComponents[appliance.icon]
                        return (
                          <motion.button
                            key={key}
                            whileHover={{ scale: 1.02, y: -2 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => handleApplianceSelect(key)}
                            className={`flex items-center gap-3 p-4 border-2 border-gray-200 rounded-xl hover:border-green-300 transition-all duration-200 bg-gradient-to-r ${appliance.color} hover:shadow-lg group`}
                          >
                            {IconComponent && <IconComponent className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />}
                            <span className="text-sm font-semibold text-white">{appliance.name}</span>
                          </motion.button>
                        )
                      })}
                    </motion.div>
                  )}

                  {/* Appliance Type Selection */}
                  {currentStep === 'selectType' && selectedAppliance && !isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-3 mt-4"
                    >
                      {['Integrated (Built-in)', 'Freestanding', 'Other/Not Sure'].map((type, index) => (
                        <motion.button
                          key={index}
                          whileHover={{ scale: 1.02, x: 4 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => handleApplianceTypeSelect(type)}
                          className="w-full text-left p-4 border-2 border-purple-200 rounded-xl hover:bg-purple-50 hover:border-purple-300 transition-all duration-200 hover:shadow-md bg-gradient-to-r from-purple-50 to-purple-100"
                        >
                          <div className="flex items-center gap-3">
                            <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                            <span className="text-sm font-medium text-gray-700">{type}</span>
                          </div>
                        </motion.button>
                      ))}
                    </motion.div>
                  )}

                  {/* Fault Selection */}
                  {currentStep === 'selectFault' && selectedAppliance && !isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-2 mt-4"
                    >
                      {appliances[selectedAppliance].faults.map((fault, index) => (
                        <motion.button
                          key={index}
                          whileHover={{ scale: 1.02, x: 4 }}
                          whileTap={{ scale: 0.98 }}
                          onClick={() => handleFaultSelect(fault)}
                          className="w-full text-left p-3 border border-blue-200 rounded-xl hover:bg-blue-50 hover:border-blue-300 transition-all duration-200 hover:shadow-md"
                        >
                          <span className="text-sm font-medium text-gray-700">{fault}</span>
                        </motion.button>
                      ))}
                    </motion.div>
                  )}

                  {/* Contact Info Collection */}
                  {currentStep === 'collectInfo' && selectedAppliance && selectedFault && !isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4"
                    >
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setShowContactForm(true)}
                        className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white p-4 rounded-xl font-medium transition-all duration-200 flex items-center justify-center gap-2 shadow-md"
                      >
                        <User className="w-5 h-5" />
                        Provide Contact Details
                      </motion.button>
                    </motion.div>
                  )}

                  {/* Completed Actions */}
                  {currentStep === 'completed' && !isTyping && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="space-y-3 mt-4"
                    >
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => window.open('tel:08007720226')}
                        className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white p-3 rounded-xl font-medium transition-all duration-200 flex items-center justify-center gap-2"
                      >
                        <Phone className="w-4 h-4" />
                        Call Us Now
                      </motion.button>
                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={resetConversation}
                        className="w-full border border-gray-300 text-gray-700 p-3 rounded-xl font-medium transition-all duration-200 hover:bg-gray-50"
                      >
                        New Request
                      </motion.button>
                    </motion.div>
                  )}

                  <div ref={messagesEndRef} />
                </div>
              )}

              {/* Input Area */}
              {!isMinimized && (
                <div className="p-4 border-t border-gray-200 bg-white">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={currentInput}
                      onChange={(e) => setCurrentInput(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                      placeholder="Ask about repairs, bookings, or quotes..."
                      className="flex-1 px-4 py-3 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-all duration-200"
                    />
                    <motion.button
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={handleSendMessage}
                      disabled={!currentInput.trim()}
                      className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 disabled:from-gray-300 disabled:to-gray-400 text-white p-3 rounded-full transition-all duration-200 shadow-md"
                    >
                      <Send className="w-5 h-5" />
                    </motion.button>
                  </div>
                  <div className="flex items-center justify-center mt-2 text-xs text-gray-500">
                    <Sparkles className="w-3 h-3 mr-1" />
                    Powered by AI • Available 24/7
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Contact Form Modal */}
      <ContactFormModal
        isOpen={showContactForm}
        onClose={() => setShowContactForm(false)}
        appliance={selectedAppliance ? appliances[selectedAppliance].name : ''}
        applianceType={applianceType || ''}
        fault={selectedFault || ''}
        onSubmitSuccess={handleContactFormSuccess}
      />
    </>
  )
}

export default EnhancedSmartChatbot