import React, { useState, useEffect, useRef } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  MessageCircle, 
  X, 
  Minimize2, 
  Send, 
  Bot,
  Wrench,
  Users,
  Heart,
  Zap
} from 'lucide-react'

const SmartChatbot = () => {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState([])
  const [currentInput, setCurrentInput] = useState('')
  const [currentStep, setCurrentStep] = useState('greeting')
  const [selectedAppliance, setSelectedAppliance] = useState(null)
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef(null)

  const appliances = {
    washer: { 
      name: 'Washing Machine', 
      icon: 'WM', 
      faults: ['Not draining', 'Not spinning', 'Leaking', 'Other problem'] 
    },
    dryer: { 
      name: 'Tumble Dryer', 
      icon: 'TD', 
      faults: ['No heat', 'Drum not turning', 'Other problem'] 
    },
    oven: { 
      name: 'Oven', 
      icon: 'OV', 
      faults: ['Not heating', 'Uneven cooking', 'Other problem'] 
    },
    dishwasher: { 
      name: 'Dishwasher', 
      icon: 'DW', 
      faults: ['Not cleaning properly', 'Not draining', 'Strange noise', 'Other problem'] 
    },
    fridge: { 
      name: 'Refrigerator', 
      icon: 'FR', 
      faults: ['Not cooling', 'Making noise', 'Leaking water', 'Other problem'] 
    }
  }

  const responses = {
    greeting: [
      "Hi there! Which appliance needs repair today?"
    ]
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const startConversation = () => {
    if (messages.length === 0) {
      setTimeout(() => {
        addBotMessage(responses.greeting[0])
        setCurrentStep('selectAppliance')
      }, 600)
    }
  }

  useEffect(() => {
    if (isOpen) {
      startConversation()
    }
  }, [isOpen])

  const addBotMessage = (txt) => {
    const msg = {
      id: Date.now(),
      type: 'bot',
      content: txt,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, msg])
  }

  const addUserMessage = (txt) => {
    const msg = {
      id: Date.now(),
      type: 'user',
      content: txt,
      timestamp: new Date()
    }
    setMessages(prev => [...prev, msg])
  }

  const selectAppliance = (key) => {
    addUserMessage(appliances[key].name)
    addBotMessage(`Great – what problem are you experiencing with your ${appliances[key].name.toLowerCase()}?`)
    setSelectedAppliance(key)
    setCurrentStep('selectFault')
  }

  const selectFault = (f) => {
    addUserMessage(f)
    addBotMessage('Thanks! One of our engineers will be in touch shortly.')
    setCurrentStep('completed')
  }

  const handleUserInput = () => {
    const input = document.getElementById('chatInput')
    const val = input.value.trim()
    if (!val) return
    addUserMessage(val)
    input.value = ''
    
    setTimeout(() => {
      if (val.toLowerCase().includes('hello') || val.toLowerCase().includes('hi')) {
        addBotMessage("Hello! I'm here to help with your appliance repairs. Which appliance needs attention?")
        setCurrentStep('selectAppliance')
      } else if (val.toLowerCase().includes('thank')) {
        addBotMessage("You're very welcome! Don't hesitate to reach out if you need any more help. Have a great day!")
      } else {
        addBotMessage("I understand. Let me help you get the right assistance. Which appliance would you like help with?")
        setCurrentStep('selectAppliance')
      }
    }, 800)
  }

  const toggleChat = () => {
    setIsOpen(!isOpen)
  }

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Toggle Button */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            exit={{ scale: 0, rotate: 180 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={toggleChat}
            className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-full p-4 shadow-2xl flex items-center gap-3 group transition-all duration-300"
          >
            <div className="w-8 h-8 rounded-full flex items-center justify-center overflow-hidden border-2 border-white shadow-lg">
              <img 
                src="/images/gar2.jpg" 
                alt="Green Appliance Repairs Assistant" 
                className="w-full h-full object-cover rounded-full"
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.nextSibling.style.display = 'flex';
                }}
              />
              <div className="w-full h-full bg-white/20 rounded-full flex items-center justify-center" style={{display: 'none'}}>
                <Bot className="w-5 h-5" />
              </div>
            </div>
            <span className="font-semibold">Smart Repair Assistant</span>
            <div className="w-3 h-3 bg-green-300 rounded-full animate-pulse"></div>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="bg-white rounded-2xl shadow-2xl w-96 h-[500px] flex flex-col overflow-hidden border border-gray-200"
          >
            {/* Chat Header */}
            <div className="bg-gradient-to-r from-green-500 to-green-600 text-white p-4 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full flex items-center justify-center overflow-hidden border-2 border-white shadow-lg">
                  <img 
                    src="/images/gar2.jpg" 
                    alt="Green Appliance Repairs Assistant" 
                    className="w-full h-full object-cover rounded-full"
                    onError={(e) => {
                      e.target.style.display = 'none';
                      e.target.nextSibling.style.display = 'flex';
                    }}
                  />
                  <div className="w-full h-full bg-white/20 rounded-full flex items-center justify-center" style={{display: 'none'}}>
                    <Bot className="w-5 h-5" />
                  </div>
                </div>
                <div>
                  <h4 className="font-semibold">Smart Appliance Assistant</h4>
                  <span className="text-sm opacity-80">Online</span>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={toggleChat}
                  className="p-1 hover:bg-white/20 rounded-full transition-colors"
                >
                  <Minimize2 className="w-4 h-4" />
                </button>
                <button
                  onClick={toggleChat}
                  className="p-1 hover:bg-white/20 rounded-full transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
              {messages.map((message) => (
                <motion.div
                  key={message.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`flex items-end gap-2 max-w-[80%] ${
                    message.type === 'user' ? 'flex-row-reverse' : 'flex-row'
                  }`}>
                    {message.type === 'bot' && (
                      <div className="w-6 h-6 rounded-full flex items-center justify-center overflow-hidden mr-2 border border-white shadow-md">
                        <img 
                          src="/images/gar2.jpg" 
                          alt="Green Appliance Repairs Assistant" 
                          className="w-full h-full object-cover rounded-full"
                          onError={(e) => {
                            e.target.style.display = 'none';
                            e.target.nextSibling.style.display = 'flex';
                          }}
                        />
                        <div className="w-full h-full bg-green-500 rounded-full flex items-center justify-center" style={{display: 'none'}}>
                          <Bot className="w-3 h-3 text-white" />
                        </div>
                      </div>
                    )}
                    <div className={`px-4 py-2 rounded-2xl ${
                      message.type === 'user' 
                        ? 'bg-blue-500 text-white rounded-br-md' 
                        : 'bg-white border border-gray-200 rounded-bl-md shadow-sm'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                    </div>
                  </div>
                </motion.div>
              ))}



              {currentStep === 'selectFault' && selectedAppliance && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-2 mt-4"
                >
                  {appliances[selectedAppliance].faults.map((fault, index) => (
                    <motion.button
                      key={index}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={() => selectFault(fault)}
                      className="w-full text-left p-3 border border-blue-200 rounded-xl hover:bg-blue-50 hover:border-blue-300 transition-all duration-200"
                    >
                      <span className="text-sm font-medium text-gray-700">{fault}</span>
                    </motion.button>
                  ))}
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Input Area */}
            <div className="p-4 border-t border-gray-200 bg-white">
              <div className="flex gap-2">
                <input
                  type="text"
                  id="chatInput"
                  onKeyPress={(e) => e.key === 'Enter' && handleUserInput()}
                  placeholder="Type your message..."
                  className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleUserInput}
                  className="bg-green-500 hover:bg-green-600 text-white p-2 rounded-full transition-colors duration-200"
                >
                  <Send className="w-5 h-5" />
                </motion.button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default SmartChatbot