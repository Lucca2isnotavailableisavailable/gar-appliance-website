import React, { createContext, useContext, useState, useCallback } from 'react'

const ChatbotContext = createContext()

export const useChatbot = () => {
  const context = useContext(ChatbotContext)
  if (!context) {
    throw new Error('useChatbot must be used within a ChatbotProvider')
  }
  return context
}

export const ChatbotProvider = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false)
  const [hasUnreadMessages, setHasUnreadMessages] = useState(false)
  const [conversations, setConversations] = useState([])

  const openChatbot = useCallback(() => {
    setIsOpen(true)
    setHasUnreadMessages(false)
  }, [])

  const closeChatbot = useCallback(() => {
    setIsOpen(false)
  }, [])

  const addNotification = useCallback(() => {
    if (!isOpen) {
      setHasUnreadMessages(true)
    }
  }, [isOpen])

  const value = {
    isOpen,
    hasUnreadMessages,
    conversations,
    openChatbot,
    closeChatbot,
    addNotification,
    setConversations
  }

  return (
    <ChatbotContext.Provider value={value}>
      {children}
    </ChatbotContext.Provider>
  )
}

export default ChatbotProvider 