import React from 'react'
import { motion } from 'framer-motion'
import { useInView } from 'react-intersection-observer'
import { Wrench, Clock, PoundSterling, Shield } from 'lucide-react'

const Services = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  })

  const services = [
    {
      name: "Washing Machines",
      price: "£65 – £85",
      type: "Freestanding",
      icon: "M18 2.01L6 2c-1.11 0-2 .89-2 2v16c0 1.11.89 2 2 2h12c1.11 0 2-.89 2-2V4c0-1.11-.89-1.99-2-1.99zM18 20H6V4h12v16zM8 5h2v2H8V5zm0 3h8v8H8V8z",
      features: ["All brands", "Same day service", "Fixed rate pricing"]
    },
    {
      name: "Tumble Dryers",
      price: "£65 – £85",
      type: "Freestanding",
      icon: "M18 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 18H6V4h12v16zM12 6c-3.31 0-6 2.69-6 6s2.69 6 6 6 6-2.69 6-6-2.69-6-6-6zm0 10c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4z",
      features: ["Heat pump & condenser", "Vented dryers", "12 month warranty"]
    },
    {
      name: "Washer Dryers",
      price: "£65 – £85",
      type: "Freestanding",
      icon: "M19 2H5c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm-8 16H6V6h5v12zm7 0h-5V6h5v12z",
      features: ["Combination units", "Space efficient", "Expert diagnosis"]
    },
    {
      name: "Dishwashers",
      price: "£65 – £85",
      type: "Freestanding",
      icon: "M8 2v2H4v2h16V4h-4V2H8zm-2 6h12v12H6V8zm2 2v8h8v-8H8z",
      features: ["Built-in & freestanding", "Water leak repairs", "Control panel fixes"]
    },
    {
      name: "Electric Ovens",
      price: "£65 – £85",
      type: "Freestanding",
      icon: "M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V5h14v14zM7 10h2v7H7zm4-3h2v10h-2zm4 6h2v4h-2z",
      features: ["Fan & conventional", "Element replacement", "Temperature issues"]
    },
    {
      name: "Electric Cookers",
      price: "£65 – £85",
      type: "Freestanding",
      icon: "M8 4V2h8v2H8zm0 4h8v12H8V8zm2 6h4v4h-4v-4z",
      features: ["Ceramic & solid plate", "Grill repairs", "Safety checks"]
    },
    {
      name: "Integrated Appliances",
      price: "£85 – £105",
      type: "Built-in",
      icon: "M20 4H4c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 14H4V6h16v12z",
      features: ["Built-in appliances", "Door mechanism", "Installation support"],
      premium: true
    },
    {
      name: "Emergency Repairs",
      price: "Same Day",
      type: "All Types",
      icon: "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
      features: ["24/7 availability", "Emergency callouts", "Priority service"],
      emergency: true
    }
  ]

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  }

  return (
    <section id="services" className="section-padding bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="text-center mb-16"
        >
          <motion.h2
            variants={itemVariants}
            className="text-3xl md:text-4xl font-bold text-gray-900 mb-6"
          >
            <span className="gradient-text">Reliable Repairs</span>, Exceptional Value
          </motion.h2>
          <motion.p
            variants={itemVariants}
            className="text-xl text-gray-600 max-w-3xl mx-auto"
          >
            We repair all current and leading makes and models at a fixed rate which covers call out charge and all labour. We only charge more if your appliance needs new parts.
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          {services.map((service, index) => (
            <motion.div
              key={service.name}
              variants={itemVariants}
              whileHover={{ scale: 1.02 }}
              className={`bg-white rounded-2xl p-6 shadow-lg border-2 transition-all duration-300 hover:shadow-xl ${
                service.premium 
                  ? 'border-yellow-200 bg-gradient-to-br from-yellow-50 to-white' 
                  : service.emergency 
                  ? 'border-red-200 bg-gradient-to-br from-red-50 to-white'
                  : 'border-gray-100 hover:border-primary-200'
              }`}
            >
              {service.premium && (
                <div className="inline-flex items-center bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-medium mb-4">
                  Premium Service
                </div>
              )}
              {service.emergency && (
                <div className="inline-flex items-center bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-medium mb-4">
                  Emergency
                </div>
              )}

              <div className="flex items-center justify-center w-16 h-16 bg-primary-100 rounded-xl mb-4 mx-auto">
                <svg className="w-8 h-8 text-primary-600" fill="currentColor" viewBox="0 0 24 24">
                  <path d={service.icon} />
                </svg>
              </div>

              <h3 className="text-xl font-bold text-gray-900 mb-2 text-center">
                {service.name}
              </h3>

              <div className="text-center mb-4">
                <div className="text-2xl font-bold text-primary-600 mb-1">
                  {service.price}
                </div>
                <div className="text-sm text-gray-500">{service.type}</div>
              </div>

              <ul className="space-y-2 mb-6">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-sm text-gray-600">
                    <div className="w-2 h-2 bg-primary-400 rounded-full mr-3 flex-shrink-0"></div>
                    {feature}
                  </li>
                ))}
              </ul>

              <motion.a
                href="#contact"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`w-full py-3 px-4 rounded-lg font-semibold transition-all duration-300 block text-center ${
                  service.premium || service.emergency
                    ? 'bg-primary-600 hover:bg-primary-700 text-white'
                    : 'bg-primary-100 hover:bg-primary-200 text-primary-700'
                }`}
              >
                Book Repair
              </motion.a>
            </motion.div>
          ))}
        </motion.div>

        {/* Key Benefits */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate={inView ? "visible" : "hidden"}
          className="mt-16 grid md:grid-cols-4 gap-8"
        >
          {[
            { icon: Clock, title: "Same Day Service", desc: "No waiting around for us" },
            { icon: PoundSterling, title: "Fixed Fees", desc: "No matter how long the job takes" },
            { icon: Shield, title: "Quality Guarantee", desc: "12 month warranty on all parts" },
            { icon: Wrench, title: "All Brands", desc: "We service every major brand" }
          ].map((benefit, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="text-center"
            >
              <div className="w-16 h-16 bg-primary-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <benefit.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">{benefit.title}</h3>
              <p className="text-gray-600">{benefit.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

export default Services 