import React from 'react'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import categories from '../data/scraped_categories'

const SalesHome = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.1,
      },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.6,
        ease: 'easeOut',
      },
    },
  }

  return (
    <section className="section-padding bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <div className="text-center mb-16">
            <motion.h2
              variants={itemVariants}
              className="text-4xl font-bold text-gray-900 mb-6"
            >
              Appliance <span className="gradient-text">Sales</span>
            </motion.h2>
            <motion.p
              variants={itemVariants}
              className="text-xl text-gray-600 max-w-3xl mx-auto"
            >
              Browse our selection of top-quality appliances. Same trusted service, now with fantastic prices.
            </motion.p>
          </div>

          <motion.div
            variants={containerVariants}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {categories.map((cat) => (
              <motion.div
                key={cat.slug}
                variants={itemVariants}
                whileHover={{ scale: 1.03 }}
                className="bg-gray-50 border border-gray-100 rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
              >
                <Link to={`/sales/${cat.slug}`} className="block h-full">
                  <img src={cat.image} alt={cat.name} className="w-full h-52 object-cover" />
                  <div className="p-6 text-center">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">{cat.name}</h3>
                    <p className="text-sm text-gray-600 mb-2">{cat.productCount} products available</p>
                    {cat.priceRange && (
                      <p className="text-sm font-medium text-primary-600">
                        From £{cat.priceRange.min} - £{cat.priceRange.max}
                      </p>
                    )}
                  </div>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>
    </section>
  )
}

export default SalesHome 