import React from 'react'
import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { getCategoryBySlug, getProductsByCategory } from '../data/scraped_categories'

const SubcategoryPage = () => {
  const { category, subcategory } = useParams()
  const cat = getCategoryBySlug(category)
  
  if (!cat) {
    return (
      <div className="section-padding text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Category not found</h2>
        <Link to="/sales" className="btn-primary">Back to Sales</Link>
      </div>
    )
  }

  const subcategoryData = cat.subcategories.find(sub => sub.slug === subcategory)
  const products = getProductsByCategory(category, subcategory)

  if (!subcategoryData || products.length === 0) {
    return (
      <div className="section-padding text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">No products found</h2>
        <p className="text-gray-600 mb-8">This subcategory doesn't have any products yet.</p>
        <Link to={`/sales/${category}`} className="btn-primary">Back to {cat.name}</Link>
      </div>
    )
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } },
  }

  const formatPrice = (price) => {
    return new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price)
  }

  return (
    <section className="section-padding bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <div className="flex items-center space-x-2 text-sm text-gray-600 mb-8">
          <Link to="/sales" className="hover:text-primary-600">Sales</Link>
          <span>→</span>
          <Link to={`/sales/${category}`} className="hover:text-primary-600">{cat.name}</Link>
          <span>→</span>
          <span className="text-gray-900">{subcategoryData.name}</span>
        </div>

        {/* Header */}
        <div className="mb-12">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {subcategoryData.name} {cat.name}
          </h1>
          <p className="text-xl text-gray-600">
            {products.length} product{products.length !== 1 ? 's' : ''} available
          </p>
        </div>

        {/* Products Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {products.map((product) => (
            <motion.div
              key={product.id}
              variants={itemVariants}
              whileHover={{ scale: 1.02 }}
              className="bg-white border border-gray-200 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden"
            >
              <Link to={`/sales/product/${product.id}`} className="block h-full">
                {/* Product Image */}
                <div className="w-full h-48 relative overflow-hidden">
                  {product.images && product.images.length > 0 ? (
                    <img
                      src={product.images[0]}
                      alt={product.name}
                      className="w-full h-full object-contain bg-white p-4"
                      onError={(e) => {
                        e.target.style.display = 'none';
                        e.target.nextSibling.style.display = 'flex';
                      }}
                    />
                  ) : null}
                  <div className={`w-full h-full bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center ${product.images && product.images.length > 0 ? 'hidden' : ''}`}>
                    <div className="text-center">
                      <div className="w-16 h-16 bg-primary-500 rounded-full mx-auto mb-2 flex items-center justify-center">
                        <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M18 2.01L6 2c-1.11 0-2 .89-2 2v16c0 1.11.89 2 2 2h12c1.11 0 2-.89 2-2V4c0-1.11-.89-1.99-2-1.99zM18 20H6V4h12v16zM8 5h2v2H8V5zm0 3h8v8H8V8z"/>
                        </svg>
                      </div>
                      <span className="text-primary-700 font-medium">{product.brand}</span>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  {/* Brand Badge */}
                  <div className="inline-flex items-center bg-primary-100 text-primary-700 px-3 py-1 rounded-full text-sm font-medium mb-3">
                    {product.brand}
                  </div>

                  {/* Product Name */}
                  <h3 className="text-lg font-semibold text-gray-900 mb-3 line-clamp-2">
                    {product.name}
                  </h3>

                  {/* Specifications */}
                  {product.specifications && Object.keys(product.specifications).length > 0 && (
                    <div className="mb-4">
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        {Object.entries(product.specifications).slice(0, 4).map(([key, value]) => (
                          <div key={key} className="flex justify-between">
                            <span className="text-gray-500 capitalize">{key.replace('_', ' ')}:</span>
                            <span className="font-medium text-gray-700">{value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Price */}
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-primary-600">
                      {product.price ? formatPrice(product.price) : 'Contact for Price'}
                    </div>
                    <div className="text-sm text-gray-500">
                      View Details →
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="mt-16 bg-gradient-to-r from-primary-500 to-primary-600 rounded-2xl p-8 text-center text-white"
        >
          <h3 className="text-2xl font-bold mb-4">Need Help Choosing?</h3>
          <p className="text-lg mb-6 opacity-90">
            Our expert team can help you find the perfect appliance for your needs
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:08007720226"
              className="bg-white text-primary-600 font-semibold py-3 px-8 rounded-lg hover:bg-gray-50 transition-colors duration-300 inline-block"
            >
              Call: 0800 772 0226
            </a>
            <a
              href="#contact"
              className="border-2 border-white text-white font-semibold py-3 px-8 rounded-lg hover:bg-white hover:text-primary-600 transition-all duration-300 inline-block"
            >
              Get Expert Advice
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

export default SubcategoryPage 