import React from 'react'
import { useParams, Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import categories from '../data/scraped_categories'

const CategoryPage = () => {
  const { category } = useParams()
  const cat = categories.find((c) => c.slug === category)
  if (!cat) return <div className="section-padding text-center">Category not found</div>

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  }
  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: { y: 0, opacity: 1, transition: { duration: 0.6 } },
  }

  return (
    <section className="section-padding bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <Link to="/sales" className="text-primary-600 font-medium mb-8 inline-block">← Back to Sales</Link>
        <h2 className="text-3xl font-bold text-gray-900 mb-8">{cat.name}</h2>
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          {cat.subcategories.map((sub) => (
            <motion.div
              key={sub.slug}
              variants={itemVariants}
              whileHover={{ scale: 1.03 }}
              className="bg-white border border-gray-100 rounded-2xl shadow-lg hover:shadow-xl transition-shadow overflow-hidden"
            >
              <Link to={`/sales/${category}/${sub.slug}`} className="block h-full">
                <div className="p-6 text-center">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{sub.name}</h3>
                  <p className="text-sm text-gray-600">{sub.products.length} products available</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}

export default CategoryPage 