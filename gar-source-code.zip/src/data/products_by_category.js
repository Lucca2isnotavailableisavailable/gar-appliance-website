export default {
  "dishwashers": [
    {
      "id": "beko-5-wash-programmes-dfn05r10-freestanding-dishw",
      "name": "Beko 5 Wash Programmes DFN05R10 \u2013 Freestanding Dishwasher",
      "brand": "Beko",
      "price": 356.99,
      "currency": "GBP",
      "description": "\u00a3285.00 Beko 5 Wash Programmes DFN05R10 \u2013 Freestanding DishwasherKey Features at a Glance Easy to use and energy efficient, this full size dishwasher comes with a choice of 5 programmes, including our quick Mini 30\u2032 programme which washes a full load in just 30 minutes. Features quick programmes, half load functions and folding plate supports. Make an Enquiry",
      "specifications": {
        "energy_rating": "A"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.945225",
      "category": "dishwashers",
      "subcategory": "freestanding",
      "features": [
        "Wash Program",
        "Features quick program",
        "half load function",
        "5 programmes",
        "energy efficient"
      ],
      "original_price": 285.0,
      "pricing_updated_at": "2025-06-19T17:56:17.965235",
      "categorization_fixed_at": "2025-06-19T18:00:38.257644",
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/c/screenshot_2023-06-16_110429.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/7/g7410sc-clst.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009dvn05c20w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/1/1190624_adf610wh_wqp12-7605d_5055833406074_.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/d/2/d2fhk26suk.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_3_.png"
      ],
      "data_merged": true
    },
    {
      "id": "bosch-serie-2-activewater-dishwasher-60cm-fully-in",
      "name": "Bosch Serie | 2 ActiveWater Dishwasher 60cm Fully Integrated",
      "brand": "Bosch",
      "price": null,
      "currency": "GBP",
      "description": "\u00a3???.?? Bosch Serie | 2 ActiveWater Dishwasher 60cm Fully IntegratedKey Features at a Glance Height-adjustable top basket: More flexibility to accomodate larger items.VarioSpeed: cleans in up to half the time with optimum cleaning and drying results.AquaStop: 100% lifetime warranty for water damages guaranteed.Glass protection technology: extra gentle handling for your delicate glasses.EcoSilence Drive: powerful, durable, quiet and efficient. Make an Enquiry",
      "specifications": {
        "energy_rating": "B"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.836992",
      "category": "dishwashers",
      "subcategory": "integrated",
      "features": [
        "Glass protection technology"
      ],
      "categorization_fixed_at": "2025-06-19T18:00:38.257728"
    },
    {
      "id": "beko-bdfn15430w-freestanding-full-size-dishwasher",
      "name": "Beko BDFN15430W Freestanding Full Size Dishwasher",
      "brand": "Beko",
      "price": 462.99,
      "currency": "GBP",
      "description": "Best price on Beko in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Beko BDFN15430W Dishwasher, 14 Place Settings, White, D Rated",
      "specifications": {
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.871907",
      "category": "dishwashers",
      "subcategory": "freestanding",
      "features": [
        "Freestanding Dishwasher 14 place settings, Full-size",
        "Colour: White",
        "47db max noise level",
        "14 place settings",
        "Up to 24 hours delay start"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/2507de11771ab37649b9670b685b4804/7/6/7634102677-lo1-20220406-140715.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9e2a38e914bb923a9a15384fca3c72aa/7/6/7634102677-lo1-20220406-140715.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/af85501193b0efd96f500780fdc0a4e0/7/6/7634102677-lo2-20220406-140751.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/7/6/7634102677-bulk-oth-20210414-111742.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/3c5f203ed6d53cd575fd980f871e4abc/7/6/7634102677-lo1-20210712-151114.png"
      ],
      "dimensions": "850mm (h) \u00a0x\u00a0\n    598mm (w) \u00a0x\u00a0\n    600mm (d)",
      "model": "BDFN15430W",
      "url": "https://www.cartersdirect.co.uk/beko-bdfn15430w.html",
      "original_price": 369.98,
      "pricing_updated_at": "2025-06-19T17:56:17.966124",
      "categorization_fixed_at": "2025-06-19T18:00:38.257737"
    },
    {
      "id": "bosch-sps2ikw01g-freestanding-slimline-dishwasher",
      "name": "Bosch SPS2IKW01G Freestanding Slimline Dishwasher",
      "brand": "Bosch",
      "price": 561.99,
      "currency": "GBP",
      "description": "Best price on Bosch in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Bosch SPS2IKW01G (A) Slimline Dishwasher, 5 Programmes, Vario Baskets, 4 Options, 48Db, 9.5L,",
      "specifications": {
        "energy_rating": "A"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.945936",
      "category": "dishwashers",
      "subcategory": "slimline",
      "features": [
        "Free-standing dishwasher, 45cm wide white",
        "48db max noise level",
        "9.5 Litres per cycle water consumption",
        "Up to 24 hours delay start",
        "45cm Dishwasher Slimline"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/5083ff0d99b7f17e32b37f10f83be428/s/p/sps2ikw01g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/2bfbd8c7aacf1bfa02c63b08131b0a42/s/p/sps2ikw01g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/1f083b3063bded1e70efdb6cd018359a/s/p/sps2ikw01g_product_image_gallery__600x600px_2.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/e08b223378d4c4e79617820fa5a9920d/s/p/sps2ikw01g_autolink_pga_600x600px_4.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/1944ea4973f42a4454d2881c890469f7/s/p/sps2ikw01g_autolink_pga_600x600px_3.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009dvs05c20w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/1/1190611__adf410wh_wqp8-7606d_5055833406104.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/m/1/m123mmm6titled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/o/hot-hp2fe10cs90wuk-a_800x800.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/d/adf430wh.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_3_.png"
      ],
      "dimensions": "845mm (h) \u00a0x\u00a0\n    450mm (w) \u00a0x\u00a0\n    600mm (d)",
      "model": "SPS2IKW01G",
      "url": "https://www.cartersdirect.co.uk/bosch-sps2ikw01g.html",
      "original_price": 449.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966129",
      "categorization_fixed_at": "2025-06-19T18:00:38.257744",
      "data_merged": true
    },
    {
      "id": "indesit-dsio3t224ezukn-integrated-slimline-dishwasher",
      "name": "Indesit DSIO3T224EZUKN Integrated Slimline Dishwasher",
      "brand": "Indesit",
      "price": 462.99,
      "currency": "GBP",
      "description": "AEG to Hotpoint and Zanussi. All domestic appliance top brands supplied, delivered and installed to Sussex and lower Surrey.",
      "specifications": {
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.872072",
      "category": "dishwashers",
      "subcategory": "integrated",
      "features": [
        "DISHWASHER FULLY INTEGRATED-SLIMLINE",
        "Colour: Model fits behind cabinet door",
        "10 place settings",
        "45cm Dishwasher Slimline",
        "Energy Rating"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/d3c9ba7073666afdc7fd99b4b89adc9b/6/1/61g1bdjrffl._ac_sl1500__1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ce26b6a4cf91297c3896978f5f5dff5c/6/1/61g1bdjrffl._ac_sl1500__1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/53f370355d950c5e7d673774e69ad764/6/1/61syh5b1fil._ac_sl1500__1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/6a18b4d7cbeaab00e4564751ae53c698/7/1/71dk955ajzl._ac_sl1500__1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/53f370355d950c5e7d673774e69ad764/7/1/7188nuwwp7l._ac_sl1500__1.jpg"
      ],
      "dimensions": "820mm (h) \u00a0x\u00a0\n    448mm (w) \u00a0x\u00a0\n    555mm (d)",
      "model": "DSIO3T224EZUKN",
      "url": "https://www.cartersdirect.co.uk/indesit-dsio3t224ezukn.html",
      "original_price": 369.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966133",
      "categorization_fixed_at": "2025-06-19T18:00:38.257748"
    },
    {
      "id": "semi-integrated-dishwasher",
      "name": "Semi integrated dishwasher",
      "brand": "Semi",
      "model": "",
      "price": 462.99,
      "currency": "GBP",
      "description": "High-quality dishwashers from Slimline",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/o/hotpoint_h3bl626buk_968761_34-0100-0250.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/3/_/3_32900781_12_04_f_hdsn_1l380pb-80-m.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_4_4.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/s/psaadw210pa00001.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/smi2hts02g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_3_.png"
      ],
      "category": "dishwashers",
      "subcategory": "integrated",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.943344",
      "url": "https://www.cartersdirect.co.uk/dishwashers/freestanding-dishwashers/semi-int-dishwasher.html",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257753"
    },
    {
      "id": "table-top-dishwasher",
      "name": "Table top dishwasher",
      "brand": "Table",
      "model": "",
      "price": 499.99,
      "currency": "GBP",
      "description": "High-quality dishwashers from Table",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/e/aeg_ffb21200cw_1164411_34-0100-0190.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_3_.png"
      ],
      "category": "dishwashers",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.945470",
      "url": "https://www.cartersdirect.co.uk/dishwashers/integrateddishwasher/dishwasher-tabletop.html",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257757"
    },
    {
      "id": "fullsize",
      "name": "Fullsize",
      "brand": "Fullsize",
      "model": "",
      "price": 549.99,
      "currency": "GBP",
      "description": "High-quality dishwashers from Fullsize",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/1/s153htx02g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/o/bosch-smv2itx18g-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/smv2htx02g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/sms2hvw67g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/w/awf.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/f/hfc-3c26-wc-b-uk-dishwashing-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_4_4.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/sms26aw08g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/b/bbgldv42320_main_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/sms26ai08g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/1/s153hax02g.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/1/s175htx06g_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/e/remote.jpg_2_27.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/q/q/qqtt.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/s/psaadw200pa00009.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_6__1_10.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/d/adf630wh.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/u/n/unhhtitled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/3/036ldf30210w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/u/n/unlljtitled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/s/fsb42607z.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/e/remote.jpg_2_23.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/c/screenshot_2023-06-16_110429.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/7/g7410sc-clst.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009din15c20_main.png"
      ],
      "category": "dishwashers",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.946621",
      "url": "https://www.cartersdirect.co.uk/dishwashers/freestanding-dishwashers.html?p=4",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257761"
    },
    {
      "id": "dishwashing",
      "name": "Dishwashing",
      "brand": "Dishwashing",
      "model": "",
      "price": null,
      "currency": "GBP",
      "description": "High-quality dishwashers from Dishwashing",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_3_.png"
      ],
      "category": "dishwashers",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:36.961801",
      "url": "https://www.cartersdirect.co.uk/dishwashers.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257765"
    },
    {
      "id": "fully-integrated-dishwasher",
      "name": "Fully integrated dishwasher",
      "brand": "Fully",
      "model": "",
      "price": 637.99,
      "currency": "GBP",
      "description": "High-quality dishwashers from Slimline",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/s/fsb42607z.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/e/remote.jpg_2_23.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009din15c20_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/d/2/d2ihl326uk_1_supersize.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/a/gaylordf.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_3_.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/61tgou1rers._ac_sl1200_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_20.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/s/hsicih4798bi.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_231376_1596.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/61g1bdjrffl._ac_sl1500__1.jpg"
      ],
      "category": "dishwashers",
      "subcategory": "integrated",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.946137",
      "url": "https://www.cartersdirect.co.uk/dishwashers/freestanding-dishwashers/fullyint-dishwasher.html",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257768"
    },
    {
      "id": "dishwasher-accessories",
      "name": "Dishwasher Accessories",
      "brand": "Dishwasher",
      "model": "",
      "price": 83.99,
      "currency": "GBP",
      "description": "High-quality dishwashers from Dishwasher",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/m/c/mcsa00572635_167301-spruehkopf_def.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/u/ausgleichsleiste-an-bedienblende-4-teilig-aeg-111838328-8-f_r-geschirrsp_ler.jpg",
        "https://www.cartersdirect.co.uk/media/amasty/amlabel/Clearancev66.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/2/4/24637_z_901482901356-zoccolomontatoaa-beu-tk100nrrxt-carbonio.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png"
      ],
      "category": "dishwashers",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.947178",
      "url": "https://www.cartersdirect.co.uk/dishwashers/dishwashing.html",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257772"
    },
    {
      "id": "slimline",
      "name": "Slimline",
      "brand": "Slimline",
      "model": "",
      "price": 309.99,
      "currency": "GBP",
      "description": "High-quality dishwashers from Slimline",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/61tgou1rers._ac_sl1200_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009dvs05c20w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/1/1190611__adf410wh_wqp8-7606d_5055833406104.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_20.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/m/1/m123mmm6titled.png"
      ],
      "category": "dishwashers",
      "subcategory": "slimline",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:41.035828",
      "url": "https://www.cartersdirect.co.uk/dishwashers/integrateddishwasher.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257775"
    },
    {
      "id": "dishdrawer-dishwashers",
      "name": "Dishdrawer Dishwashers",
      "brand": "Dishdrawer",
      "model": "",
      "price": 1374.99,
      "currency": "GBP",
      "description": "High-quality dishwashers from Dishdrawer",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/0/10242.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/p/fp-02-dd60dhi9-10-mug-dp-pr.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/p/fp-04-dd60d2hnx9-10-mug-uk-ie-dp-00_1_.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/p/fp-02-dd60ddfhx9-10-mug-dp.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/p/fp-04-dd60d4hnx9-10-mug-uk-ie-dp-00.png"
      ],
      "category": "dishwashers",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:44.001547",
      "url": "https://www.cartersdirect.co.uk/dishwashers/freestanding-dishwashers/dishdrawer.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257778"
    },
    {
      "id": "freestanding-dishdrawer",
      "name": "Freestanding dishdrawer",
      "brand": "Freestanding",
      "model": "",
      "price": null,
      "currency": "GBP",
      "description": "High-quality dishwashers from Freestanding",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_3_.png"
      ],
      "category": "dishwashers",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:44.015339",
      "url": "https://www.cartersdirect.co.uk/dishwashers/fullsize/freestanding-dishdrawer.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257782"
    }
  ],
  "tumble-dryers": [
    {
      "id": "indesit-cyda81wwgluk-freestanding-vented-tumble-dryer",
      "name": "Indesit CYDA81WWGLUK Freestanding Vented Tumble Dryer",
      "brand": "Indesit",
      "price": 349.99,
      "currency": "GBP",
      "description": "Best price on Indesit in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Indesit CYDA81WWGLUK 8kg Vented Tumble Dryer - White",
      "specifications": {
        "capacity": "7",
        "energy_rating": "A"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.959303",
      "category": "tumble-dryers",
      "subcategory": "vented",
      "features": [
        "8kg Vented Tumble Dryer - White",
        "Colour: White",
        "67db noise level",
        "8kg Load TumbleDryer",
        "Energy Rating"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/i/n/indcyda81wwgluk_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/n/indcyda81wwgluk_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/n/indcyda81wwgluk_2.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/n/indcyda81wwgluk_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/n/indcyda81wwgluk_4.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_tvm07w_a20240710-1653-199qgff.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/8/1/81caxcmlzll._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/n/indcyda81wwgluk_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/g/gggg321.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/3/036lta09020w_main.jpg"
      ],
      "dimensions": "846mm (h) \u00a0x\u00a0\n    597mm (w) \u00a0x\u00a0\n    584mm (d)",
      "model": "CYDA81WWGLUK",
      "url": "https://www.cartersdirect.co.uk/indesit-cyda81wwgluk.html",
      "original_price": 279.99,
      "pricing_updated_at": "2025-06-19T17:56:17.965922",
      "categorization_fixed_at": "2025-06-19T18:00:38.257791",
      "data_merged": true
    },
    {
      "id": "indesit-nis41v-compact-tumble-dryer",
      "name": "Indesit NIS41V Compact Tumble Dryer",
      "brand": "Indesit",
      "price": 299.99,
      "currency": "GBP",
      "description": "Best price on INDESIT IS41V Compact Vented Tumble Dryer in Brighton Haywards Heath Worthing Southwick, Storrington or Horsham Sussex? Have a huge selection of tumble dryers on display. Buy online or visit in store. Hundreds of models in stock, ready for d",
      "specifications": {
        "capacity": "3",
        "energy_rating": "A"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.961627",
      "category": "tumble-dryers",
      "subcategory": "vented",
      "features": [
        "TUMBLE DRYER Compact Vented 4kg",
        "Weight: 25.00kg",
        "Colour: White",
        "(Up to) 4kg Load TumbleDryer",
        "Energy Rating"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/n/i/nis41v0.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/n/i/nis41v0.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/n/i/nis41v.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/n/i/nis41v4.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/n/i/nis41v0_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_td03vfw_a20240701-1653-1kx3tr2.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/n/i/nis41v0.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/n/v/nv4d01p.jpg",
        "https://www.cartersdirect.co.uk/media/amasty/amlabel/D-183C3730_00001_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png"
      ],
      "dimensions": "670mm (h) \u00a0x\u00a0\n    490mm (w) \u00a0x\u00a0\n    490mm (d)",
      "model": "NIS41V",
      "url": "https://www.cartersdirect.co.uk/indesit-nis41v.html",
      "original_price": 229.99,
      "pricing_updated_at": "2025-06-19T17:56:17.965934",
      "categorization_fixed_at": "2025-06-19T18:00:38.257800",
      "data_merged": true
    },
    {
      "id": "statesman-tvm07w-freestanding-vented-tumble-dryer",
      "name": "Statesman TVM07W Freestanding Vented Tumble Dryer",
      "brand": "Statesman",
      "price": 279.99,
      "currency": "GBP",
      "description": "Best price on Statesman in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Statesman TVM07W 7kg vented sensor tumble dryer white",
      "specifications": {
        "capacity": "7",
        "energy_rating": "B"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.871814",
      "category": "tumble-dryers",
      "subcategory": "vented",
      "features": [
        "7kg Vented Tumble Dryer White",
        "Colour: White",
        "7kg Load TumbleDryer",
        "Energy Rating",
        "2 Yr Warranty"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/p/i/pikapak_tvm07w_a20240710-1653-199qgff.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/p/i/pikapak_tvm07w_a20240710-1653-199qgff.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/p/i/pikapak_tvm07w_e20240710-1653-1i8nb12.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/p/i/pikapak_tvm07w_b20240710-1653-1np7m67.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/p/i/pikapak_tvm07w_c20240710-1653-55n71s.jpg"
      ],
      "dimensions": "840mm (h) \u00a0x\u00a0\n    595mm (w) \u00a0x\u00a0\n    555mm (d)",
      "model": "TVM07W",
      "url": "https://www.cartersdirect.co.uk/statesman-tvm07w.html",
      "original_price": 209.99,
      "pricing_updated_at": "2025-06-19T17:56:17.965940",
      "categorization_fixed_at": "2025-06-19T18:00:38.257806"
    },
    {
      "id": "beko-freestanding-white-7kg-vented-tumble-dryer-dr",
      "name": "Beko Freestanding White 7kg Vented Tumble Dryer DRVS73",
      "brand": "Beko",
      "price": 340.99,
      "currency": "GBP",
      "description": "Beko Freestanding White 7kg Vented Tumble Dryer DRVS73Key Features at a Glance This condenser dryer\u2019s 8kg load capacity allows you to dry larger items with ease. It can also prevent the over-drying of clothes with sensor programmes, which stop the cycle when the optimal dryness level has been reached. Make an Enquiry \u00a3270.00",
      "specifications": {
        "capacity": "7",
        "energy_rating": "B"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.838126",
      "category": "tumble-dryers",
      "subcategory": "condenser",
      "features": [
        "drying of clothes with sensor program",
        "which stop the cycle"
      ],
      "original_price": 270.0,
      "pricing_updated_at": "2025-06-19T17:56:17.965946",
      "categorization_fixed_at": "2025-06-19T18:00:38.257820"
    },
    {
      "id": "tumble-dryers",
      "name": "Tumble Dryers",
      "brand": "Tumble",
      "model": "",
      "price": 787.99,
      "currency": "GBP",
      "description": "High-quality tumble dryers from Tumble",
      "specifications": {
        "capacity": "8",
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/_/a_5_2.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/3/3/333_5.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/s/pshot_34_zmp_000000000011871900.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/c/tcr780wp1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_tvm07w_a20240710-1653-199qgff.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/3/036ltp18320w_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/n/t/nt-m11-82xb-uk-tumble-dryers-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/6/t6dbg720n-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/6/t6dbg822n.jpg",
        "https://www.cartersdirect.co.uk/media/amasty/amlabel/D-183C3730_00001_1.png"
      ],
      "category": "tumble-dryers",
      "subcategory": "vented",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.960014",
      "url": "https://www.cartersdirect.co.uk/laundry/tumble-dryer.html",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257825"
    },
    {
      "id": "condenser-tumble-dryer",
      "name": "Condenser tumble dryer",
      "brand": "Condenser",
      "model": "",
      "price": 319.99,
      "currency": "GBP",
      "description": "High-quality tumble dryers from Condenser",
      "specifications": {
        "capacity": "9",
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/2/8/280zdct700w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/d/t/dtlce80051w_1_supersize.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009dtlce80041w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_227813_1596.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/9/094hlec8dg_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/_/a_5_2.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/3/3/333_5.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/s/pshot_34_zmp_000000000011871900.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/c/tcr780wp1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/l/hleh8a2te_h.jpg"
      ],
      "category": "tumble-dryers",
      "subcategory": "condenser",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.961147",
      "url": "https://www.cartersdirect.co.uk/laundry/tumble-dryer/condensertumbledryer.html",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257830"
    },
    {
      "id": "integrated-tumble-dryer",
      "name": "Integrated tumble dryer",
      "brand": "Integrated",
      "model": "",
      "price": 712.99,
      "currency": "GBP",
      "description": "High-quality tumble dryers from Integrated",
      "specifications": {
        "capacity": "7",
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_252677_1596.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_275519_1596.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/_/a_6_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/d/tdi4001.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/Integrated-Tumble-Dryers2.jpg"
      ],
      "category": "tumble-dryers",
      "subcategory": "vented",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:38.102581",
      "url": "https://www.cartersdirect.co.uk/laundry/tumble-dryer/int-tumbledryer.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257858"
    },
    {
      "id": "why-buy-a-heat-pump-tumble-dryer",
      "name": "Why buy a Heat Pump Tumble Dryer",
      "brand": "Why",
      "model": "",
      "price": null,
      "currency": "GBP",
      "description": "High-quality tumble dryers from Why",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/AEG-heat-pump-dryer.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/Save-Money-1.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/heat-pump-dryers-lifestyle.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png"
      ],
      "category": "tumble-dryers",
      "subcategory": "heat-pump",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:40.376632",
      "url": "https://www.cartersdirect.co.uk/other-info/featured-manufacturers/why-buy-a-heat-pump-tumble-dryer.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257865"
    }
  ],
  "washer-dryers": [
    {
      "id": "indesit-ecotime-iwdd-7123-washer-dryer",
      "name": "Indesit Ecotime IWDD 7123 Washer Dryer",
      "brand": "Indesit",
      "price": null,
      "currency": "GBP",
      "description": "Indesit Ecotime IWDD 7123 Washer DryerKey Features at a Glance This Indesit freestanding Washer Dryer features: white colour and a 7kg drum. Washing capacity (kg): 7Drying capacity (kg): 5Spin Speed (rpm): 1200Type: Free-standing Make an Enquiry \u00a3???.??",
      "specifications": {
        "capacity": "7",
        "energy_rating": "d"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.836116",
      "category": "washer-dryers",
      "subcategory": "freestanding",
      "features": [],
      "categorization_fixed_at": "2025-06-19T18:00:38.257874"
    },
    {
      "id": "beko-wdl742441w-freestanding-washer-dryer",
      "name": "Beko WDL742441W Freestanding Washer Dryer",
      "brand": "Beko",
      "price": 511.99,
      "currency": "GBP",
      "description": "Best price on Beko WDL742441W 7Kg/4Kg 1200 Spin Washer Dryer - White - E/D Energy Rated in Brighton Haywards Heath Worthing Southwick, Storrington or Horsham Sussex? Have a huge selection of Washer Dryers on display. Buy online or visit in store. Hundreds",
      "specifications": {
        "capacity": "8",
        "spin_speed": "1200",
        "energy_rating": "A",
        "wash_capacity": "7",
        "dry_capacity": "4"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.962078",
      "category": "washer-dryers",
      "subcategory": "freestanding",
      "features": [
        "Guaranteed lowest UK price! High Street or Online",
        "WASHER DRYER-1200rpm spin 7kg/4kg load capacity",
        "Colour: White",
        "15 Programmes programmes",
        "1200rpm spinspeed"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ece6e89075e6e3107b2f9b4ffbff10b8/0/0/009wdl742441w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/1ad9f4a72622ddbdbd1e0eb978046e49/0/0/009wdl742441w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/a813d33f3e7a1b1a2c7eaa8055541547/0/0/009wdl742441w_2.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/1790f5b9db6d26cb37ee5563569fc47c/0/0/009wdl742441w_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f7b92205c9c431d5bfe084794a909cd5/e/d/ed.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/t/statesman_fwd08514w_1221705_34-0100-0014.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/v/hvrh3dps4866tam6_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_4_5.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/_/h_7.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009wdl742441w_main.png"
      ],
      "dimensions": "840mm (h) \u00a0x\u00a0\n    600mm (w) \u00a0x\u00a0\n    490mm (d)",
      "model": "WDL742441W",
      "url": "https://www.cartersdirect.co.uk/beko-wdl742441w.html",
      "original_price": 409.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966078",
      "categorization_fixed_at": "2025-06-19T18:00:38.257881",
      "data_merged": true
    },
    {
      "id": "indesit-ewde761483w-freestanding-washer-dryer",
      "name": "Indesit EWDE761483W Freestanding Washer Dryer",
      "brand": "Indesit",
      "price": 499.99,
      "currency": "GBP",
      "description": "Best price on Indesit in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Indesit EWDE761483W Uk 869991668710 Washer-Dryers D/C, 7+6Kg, 1400 Rpm, White",
      "specifications": {
        "capacity": "7",
        "spin_speed": "1400",
        "energy_rating": "B",
        "wash_capacity": "7",
        "dry_capacity": "6"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.871613",
      "category": "washer-dryers",
      "subcategory": "freestanding",
      "features": [
        "Washer Dryer in White 1400rpm 7kg/6kg D Rated",
        "Colour: White",
        "1400rpm spinspeed",
        "78 (dB) Noise level Spinning",
        "6kg drying capacity"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/i/m/image_4_5.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/m/image_4_5.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/m/image_2__5_3.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/m/image_1__5_6.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/m/image_3__4_10.jpg"
      ],
      "dimensions": "850mm (h) \u00a0x\u00a0\n    595mm (w) \u00a0x\u00a0\n    535mm (d)",
      "model": "EWDE761483W",
      "url": "https://www.cartersdirect.co.uk/indesit-ewde761483w.html",
      "original_price": 399.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966094",
      "categorization_fixed_at": "2025-06-19T18:00:38.257887"
    },
    {
      "id": "indesit-bde86436xwukn-freestanding-washer-dryer",
      "name": "Indesit BDE86436XWUKN Freestanding Washer Dryer",
      "brand": "Indesit",
      "price": 524.99,
      "currency": "GBP",
      "description": "Best price on Indesit BDE86436XWUKN Washer Dryers 8Kg Dry , 6Kg Dry 1400Spin White  in Brighton, Haywards Heath, Worthing, Southwick, Storrington or Horsham Sussex? Have a huge selection of washer dryers on display. Buy online or visit in store.",
      "specifications": {
        "capacity": "8",
        "spin_speed": "1400",
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.871674",
      "category": "washer-dryers",
      "subcategory": "freestanding",
      "features": [
        "Freestanding 1400spin 8kg Wash 6kg Dry Washer Dryer",
        "Colour: White",
        "1400rpm spinspeed",
        "75 (dB) Noise level Spinning",
        "6kg drying capacity"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/g/_/g_3_6.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/g/_/g_3_6.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/g/g/gg_2_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/h/h/hh_5_9.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/h/h/hhh_4_16.png"
      ],
      "dimensions": "850mm (h) \u00a0x\u00a0\n    595mm (w) \u00a0x\u00a0\n    540mm (d)",
      "model": "BDE86436XWUKN",
      "url": "https://www.cartersdirect.co.uk/indesit-bde86436xwukn.html",
      "original_price": 419.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966107",
      "categorization_fixed_at": "2025-06-19T18:00:38.257893"
    },
    {
      "id": "washer-dryers",
      "name": "Washer Dryers",
      "brand": "Washer",
      "model": "",
      "price": 562.99,
      "currency": "GBP",
      "description": "High-quality washer dryers from Washer",
      "specifications": {
        "capacity": "8",
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_11.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/_/a_5_5.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/g/ggg_1_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/o/hot-ndb9635bsuk-a.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/k/k/kkkkk_3.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/n/wng254r1gb_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/n/wng25401gb_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/s/psaawd240pe00003.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/e/remote.jpg_2_19.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/l/7/l7we74634bi.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/n/indesit_bde96436svuk_1162569_34-0100-0311.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/l/g/lg_fwy606wwln1_1032837_34-0100-0092_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_26.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/d/cda-ci981a_600x600.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/b/bbglrf854311w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/g/ggg_2.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/a/samsung-series-5-wd90dg5b15beeu-9kg6kg-white-freestanding-washer-dryer.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/e/remote.jpg_2_6.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/g/ggg_6.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/s/psaawd240pe00002.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/t/statesman_fwd08514w_1221705_34-0100-0014.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/v/hvrh3dps4866tam6_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_4_5.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/_/h_7.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009wdl742441w_main.png"
      ],
      "category": "washer-dryers",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.963395",
      "url": "https://www.cartersdirect.co.uk/laundry/washer-dryers.html?p=2",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257898"
    },
    {
      "id": "integrated-washer-dryer",
      "name": "Integrated washer dryer",
      "brand": "Integrated",
      "model": "",
      "price": 549.99,
      "currency": "GBP",
      "description": "High-quality washer dryers from Integrated",
      "specifications": {
        "capacity": "7",
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/n/indbiwdil75148uk_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/r/rr_1_4.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_11.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/a/aa_5_4.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_21.jpg"
      ],
      "category": "washer-dryers",
      "subcategory": "integrated",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:38.077997",
      "url": "https://www.cartersdirect.co.uk/laundry/washer-dryers/int-washer-dryer.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257903"
    }
  ],
  "washing-machines": [
    {
      "id": "hotpoint-biwmhg71483ukn-integrated-washing-machine",
      "name": "Hotpoint BIWMHG71483UKN Integrated Washing Machine",
      "brand": "Hotpoint",
      "price": 524.99,
      "currency": "GBP",
      "description": "Best price on Hotpoint BIWMHG71483UKN Built In 7Kg 1400 Washer, D Energy, Antistain 100/ Quick in Brighton Haywards Heath Worthing Southwick, Storrington or Horsham Sussex? Have a huge selection of built in washing machines on display. Buy online o",
      "specifications": {
        "capacity": "8",
        "spin_speed": "1400",
        "energy_rating": "A"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.958075",
      "category": "washing-machines",
      "subcategory": "integrated",
      "features": [
        "BUILT IN 1400Spin 7Kg WASHING MACHINE",
        "Colour: Integrated, Door Panel Ready",
        "16 Programmes programmes",
        "1400rpm spinspeed",
        "7kg load WashingMachine"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/h/o/hot-biwmhg71483ukna.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/h/o/hot-biwmhg71483ukna.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/h/o/hot-biwmhg71483uknb.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/h/o/hot-biwmhg71483uknc.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/i/m/image_1__2.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/t/atbiwm814w.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/i/biwmil71252uk.alt2_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009wtik74151f_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/_/1_5_5.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/61g15v_7ail._ac_sl1500_.jpg"
      ],
      "dimensions": "815mm (h) \u00a0x\u00a0\n    595mm (w) \u00a0x\u00a0\n    545mm (d)",
      "model": "BIWMHG71483UKN",
      "url": "https://www.cartersdirect.co.uk/hotpoint-biwmhg71483ukn.html",
      "original_price": 419.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966114",
      "categorization_fixed_at": "2025-06-19T18:00:38.257909",
      "data_merged": true
    },
    {
      "id": "beko-freestanding-a-8kg-1400rpm-washing-machine-wt",
      "name": "Beko Freestanding A 8kg 1400rpm Washing Machine WTB841R2",
      "brand": "Beko",
      "price": 412.99,
      "currency": "GBP",
      "description": "Beko Freestanding A 8kg 1400rpm Washing Machine WTB841R2Key Features at a Glance This slim depth washing machine can wash a full 8kg load in just 28 minutes, speeding up your everyday wash. Its Fast+ function can also shorten the length of other programmes, saving you even more time and money. Make an Enquiry \u00a3330.00",
      "specifications": {
        "capacity": "8",
        "spin_speed": "1400",
        "energy_rating": "B"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.836742",
      "category": "washing-machines",
      "subcategory": "freestanding",
      "features": [
        "function can also shorten the length of other program"
      ],
      "original_price": 330.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966143",
      "categorization_fixed_at": "2025-06-19T18:00:38.257933"
    },
    {
      "id": "bosch-serie-2-automatic-washing-machine-wab28161gb",
      "name": "Bosch Serie | 2 Automatic Washing Machine- WAB28161GB",
      "brand": "Bosch",
      "price": 475.99,
      "currency": "GBP",
      "description": "Bosch Serie | 2 Automatic Washing Machine- WAB28161GBKey Features at a Glance Automatic washing machine with EcoSilence Drive\u2122: quiet operation and durability that you can rely on. EcoSilence Drive\u2122: extremely energy-efficient and quiet in operation with a 10-year warranty.VarioPerfect\u2122: takes 65% less time or uses 50% less energy \u2013 delivers total flexibility.ActiveWater\u2122: saves water and costs thanks to a 2-step automatic load adjustment system.Easy operation with LED-Display and convenient control dial.Noise Level 53dB/74dB: quiet washing and spinning. Make an Enquiry \u00a3380.00",
      "specifications": {
        "energy_rating": "B",
        "noise_level": "53"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.837406",
      "category": "washing-machines",
      "subcategory": "freestanding",
      "features": [
        "step automatic load adjustment system",
        "quiet operation",
        "Automatic",
        "automatic"
      ],
      "original_price": 380.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966148",
      "categorization_fixed_at": "2025-06-19T18:00:38.257951"
    },
    {
      "id": "beko-integrated-7kg-washing-machine-wir725451",
      "name": "Beko Integrated 7kg Washing Machine WIR725451",
      "brand": "Beko",
      "price": 473.99,
      "currency": "GBP",
      "description": "\u00a3379.00 Beko Integrated 7kg Washing Machine WIR725451Key Features at a Glance This integrated washing machine allows you to wash a full 7kg load in just 28 minutes, speeding up your everyday wash. To save you even more time, other programme durations can also be cut down with our Fast+ function. Make an Enquiry",
      "specifications": {
        "capacity": "7",
        "wash_capacity": "7",
        "energy_rating": "B"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.837827",
      "category": "washing-machines",
      "subcategory": "integrated",
      "features": [
        "other program"
      ],
      "original_price": 379.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966152",
      "categorization_fixed_at": "2025-06-19T18:00:38.257961"
    },
    {
      "id": "bosch-serie-4-automatic-washing-machine",
      "name": "Bosch Serie | 4 Automatic Washing Machine",
      "brand": "Bosch",
      "price": null,
      "currency": "GBP",
      "description": "\u00a3???.?? Bosch Serie | 4 Automatic Washing MachineKey Features at a Glance Automatic washing machine with EcoSilence Drive\u2122: quiet operation and durability that you can rely on. EcoSilence Drive\u2122: extremely energy-efficient and quiet in operation with a 10-year warranty.VarioPerfect\u2122: takes 65% less time or uses 50% less energy \u2013 delivers total flexibility.ActiveWater\u2122: saves water and costs thanks to a 2-step automatic load adjustment system.Easy operation with LED-Display and convenient control dial.Noise Level 53dB/74dB: quiet washing and spinning. Make an Enquiry",
      "specifications": {
        "energy_rating": "B",
        "noise_level": "53"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.838547",
      "category": "washing-machines",
      "subcategory": "freestanding",
      "features": [
        "step automatic load adjustment system",
        "quiet operation",
        "Automatic",
        "automatic"
      ],
      "categorization_fixed_at": "2025-06-19T18:00:38.257977"
    },
    {
      "id": "statesman-biw0814",
      "name": "Statesman BIW0814",
      "brand": "Statesman",
      "price": 499.99,
      "currency": "GBP",
      "description": "Best price on Statesman in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Statesman BIW0814 8Kg 1400Rpm Built-In Washing Machine White",
      "specifications": {
        "capacity": "8",
        "spin_speed": "1400",
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.871188",
      "category": "washing-machines",
      "subcategory": "freestanding",
      "features": [
        "8kg 1400rpm Built-In Washing Machine",
        "Colour: Integrated, Door Panel Ready",
        "1400rpm spinspeed",
        "Up to 24 hours delay start",
        "8kg load WashingMachine"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/fda2a0b0e66d424465553b3926183383/6/1/61g15v_7ail._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/09edb489bcef1dcd68e31d788d38b616/6/1/61g15v_7ail._ac_sl1500_.jpg"
      ],
      "dimensions": "825mm (h) \u00a0x\u00a0\n    595mm (w) \u00a0x\u00a0\n    540mm (d)",
      "model": "BIW0814",
      "url": "https://www.cartersdirect.co.uk/statesman-biw0814.html",
      "original_price": 399.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966354",
      "categorization_fixed_at": "2025-06-19T18:00:38.257983"
    },
    {
      "id": "washing-machines",
      "name": "Washing Machines",
      "brand": "Washing",
      "model": "",
      "price": 374.99,
      "currency": "GBP",
      "description": "High-quality washing machines from Washing",
      "specifications": {
        "capacity": "8",
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/7/_/7_2.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/v/hvrh3w48ta4_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/t/atbiwm814w.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/m/t/mtwc81495wuk_1_supersize.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/u/n/untitoooooooled.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/Miele_Logo.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/TwinDos.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/CapDosing.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/QuickPowerWash.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/Stain-Option.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/c/screenshot_2023-07-04_162851.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/n/s/nswm864cggukn_1_12200389_supersize.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_27.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/b/bbglwf184620g_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/1/a1nswm1046wuk_1_supersize.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/e/weg365.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/e/we_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/m/wme610_-_front.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/3/8/38854701_l.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/v/c/vcccccuntitled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/p/ppp_1_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/n/s/nswm1046gguk.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/_/1_5_5.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/c/screenshot_2023-12-21_093100.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/e/remote.jpg_3_34.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_7__3_3.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/e/bekbmn3wt3841b_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/e/bekbmn3wt3841s_main_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/2/4/24413-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/v/_/v_2.png"
      ],
      "category": "washing-machines",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.958745",
      "url": "https://www.cartersdirect.co.uk/laundry/washing-machines.html?p=2",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.257987"
    },
    {
      "id": "freestanding-washing-machine",
      "name": "Freestanding washing machine",
      "brand": "Freestanding",
      "model": "",
      "price": 1362.99,
      "currency": "GBP",
      "description": "High-quality washing machines from Freestanding",
      "specifications": {
        "capacity": "9",
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/e/weg365.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/e/we_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/w/m/wme610_-_front.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/3/8/38854701_l.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/v/c/vcccccuntitled.png"
      ],
      "category": "washing-machines",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:41.479207",
      "url": "https://www.cartersdirect.co.uk/laundry/washing-machines/washing-machine.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.257992"
    }
  ],
  "appliances": [
    {
      "id": "cda-ci327-integrated-washing-machine",
      "name": "CDA CI327 Integrated Washing Machine",
      "brand": "Cda",
      "price": 499.99,
      "currency": "GBP",
      "description": "Best price on CDA CI327 Laundry Integrated Washing Machine, 1400 Spin Speed, 7Kg Wash Load in Brighton Haywards Heath Worthing Southwick, Storrington or Horsham Sussex? Have a huge selection of built in washing machines on display. Buy online or visit in",
      "specifications": {
        "capacity": "7",
        "spin_speed": "1400",
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.871238",
      "category": "appliances",
      "subcategory": "freestanding",
      "features": [
        "Built In 1400spin 7kg Washing Machine",
        "Colour: Integrated, Door Panel Ready",
        "16 programmes programmes",
        "1400rpm spinspeed",
        "76 (db) Noise level Spinning"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/1/_/1_5_5.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/1/_/1_5_5.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/2/_/2_1_1.jpg"
      ],
      "dimensions": "830mm (h) \u00a0x\u00a0\n    600mm (w) \u00a0x\u00a0\n    540mm (d)",
      "model": "CDACI327",
      "url": "https://www.cartersdirect.co.uk/cda-ci327.html",
      "original_price": 399.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966119",
      "categorization_fixed_at": "2025-06-19T18:00:38.258015"
    },
    {
      "id": "hotpoint-biwmhg71284-7kg-1200rpm-integrated-washin",
      "name": "Hotpoint BIWMHG71284 7kg 1200rpm Integrated Washing Machine",
      "brand": "Hotpoint",
      "price": 562.99,
      "currency": "GBP",
      "description": "\u00a3450.00 Hotpoint BIWMHG71284 7kg 1200rpm Integrated Washing MachineKey Features at a Glance 7kg Wash load capacity and 5kg drying load capacity.Anti Stain 100 \u2013 It takes care of your clothes with Antistain 100 cycle, by removing more than 100 stains at only 40\u00b0 in one wash without pre-treatment.Anti Stain Quick \u2013 Remove more than 30 natural stains @40 without pre treatment in just 45\u2019*. (results obtained on cotton).Woolmark \u2013 Care for your woollens with a delicate wash programme that ensures a perfect clean whilst protecting the fabric\u2019s softness. Make an Enquiry",
      "specifications": {
        "capacity": "7",
        "spin_speed": "1200",
        "wash_capacity": "7",
        "dry_capacity": "5",
        "energy_rating": "B"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T15:31:31.836368",
      "category": "appliances",
      "subcategory": "freestanding",
      "features": [
        "Care for your woollens with a delicate wash program"
      ],
      "original_price": 450.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966138",
      "categorization_fixed_at": "2025-06-19T18:00:38.258039"
    },
    {
      "id": "hair-dryer",
      "name": "Hair dryer",
      "brand": "Hair",
      "model": "",
      "price": 85.99,
      "currency": "GBP",
      "description": "High-quality appliances from Hair",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/7/1/71u5jdzc7gl._sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/7/1/71uip8mfndl._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/7/1/71ykjme7fkl._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/8/c81062bc.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/r/e/remington_ri3010_1201668_34-0100-0354.jpg"
      ],
      "category": "appliances",
      "subcategory": "freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:43.987379",
      "url": "https://www.cartersdirect.co.uk/small-items/personal/hair-dryers.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258044"
    }
  ],
  "ovens": [
    {
      "id": "hotpoint-du2540bl-built-under-double-oven",
      "name": "Hotpoint DU2540BL Built Under Double Oven",
      "brand": "Hotpoint",
      "price": 512.99,
      "currency": "GBP",
      "description": "Best price onHotpoint DU2540BL Hotpoint Double Built Under Electric Oven in Brighton Haywards Heath Worthing Southwick, Storrington or Horsham Sussex? Have a huge selection of built under ovens on display. Buy online or visit in store. Hundreds of models",
      "specifications": {
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.872131",
      "category": "ovens",
      "subcategory": "double-built-in",
      "features": [
        "Double Built Under Electric Oven",
        "Black DOUBLE BLT-UNDER COUNTER OVEN",
        "Colour: Black",
        "Conventional Oven (secondary)",
        "Fan Assisted Oven (main)"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/d/u/du2540bl_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/d/u/du2540bl_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/d/u/du2540bl.alt4.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/d/u/du2540bl.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/d/u/du2540bl.alt3.jpg"
      ],
      "dimensions": "720mm (h) \u00a0x\u00a0\n    597mm (w) \u00a0x\u00a0\n    578mm (d)",
      "model": "DU2540BL",
      "url": "https://www.cartersdirect.co.uk/hotpoint-du2540bl.html",
      "original_price": 409.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966362",
      "categorization_fixed_at": "2025-06-19T18:00:38.258052"
    },
    {
      "id": "beko-cify71w-built-in-single-oven",
      "name": "Beko CIFY71W Built In Single Oven",
      "brand": "Beko",
      "price": 269.99,
      "currency": "GBP",
      "description": "Best price on Beko CIFY71W Built In Electric Single Oven - White - A Energy Rated in Brighton Haywards Heath Worthing Southwick, Storrington or Horsham Sussex? Have a huge selection of built in ovens on display. Buy online or visit in store. Hundreds of m",
      "specifications": {
        "capacity": "70",
        "energy_rating": "A"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.953290",
      "category": "ovens",
      "subcategory": "single-built-in",
      "features": [
        "Guaranteed lowest UK price! High Street or Online",
        "SINGLE BLT-IN OVEN-MULTIFUNCTION-White",
        "Weight: 28.70kg",
        "Colour: White",
        "Multifunction oven-5 Functions"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/b8579c816ad09bc531869055a9f2f9b7/0/0/009cify71w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/0/0/009cify71w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/d4d1eb2f77796e42c78f7e0d8e35e233/0/0/009cify71w_04.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/e2dc2ad74a9cb4216a6834bb7d417861/0/0/009cify71w_05.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_bsf60ss_a_06102120240509-1653-1xucz5v.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_bsf60wh_a_06102120240502-1653-7x6v3u_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/61on1fchhel._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/y/u/yuntitled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/b/hbg674bb1b.jpg"
      ],
      "dimensions": "595mm (h) \u00a0x\u00a0\n    594mm (w) \u00a0x\u00a0\n    567mm (d)",
      "model": "CIFY71W",
      "url": "https://www.cartersdirect.co.uk/beko-cify71w.html",
      "original_price": 199.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966366",
      "categorization_fixed_at": "2025-06-19T18:00:38.258061",
      "data_merged": true
    },
    {
      "id": "statesman-bsf60wh-built-in-single-oven",
      "name": "Statesman BSF60WH Built In Single Oven",
      "brand": "Statesman",
      "price": 269.99,
      "currency": "GBP",
      "description": "Best price on Statesman in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Statesman BSF60WH Built In Single Oven 65 Litre Net White",
      "specifications": {
        "energy_rating": "B"
      },
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.872247",
      "category": "ovens",
      "subcategory": "single-built-in",
      "features": [
        "SINGLE BLT-IN OVEN-MULTIFUNCTION-White",
        "Colour: White",
        "65lt net litres capacity",
        "Multi Function Fan Assisted Oven",
        "Energy Rating"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/p/i/pikapak_bsf60wh_a_06102120240502-1653-7x6v3u_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/p/i/pikapak_bsf60wh_a_06102120240502-1653-7x6v3u_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/p/i/pikapak_bsf60wh_b20240502-1653-bpbn88.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/p/i/pikapak_bsf60wh_a_06102120240502-1653-7x6v3u.jpg"
      ],
      "dimensions": "595mm (h) \u00a0x\u00a0\n    595mm (w) \u00a0x\u00a0\n    575mm (d)",
      "model": "BSF60WH",
      "url": "https://www.cartersdirect.co.uk/statesman-bsf60wh.html",
      "original_price": 199.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966371",
      "categorization_fixed_at": "2025-06-19T18:00:38.258068"
    },
    {
      "id": "splashbacks",
      "name": "Splashbacks",
      "brand": "Splashbacks",
      "model": "",
      "price": 119.99,
      "currency": "GBP",
      "description": "High-quality ovens from Splashbacks",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/p/sp-60-cvd-bg.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/p/sp-70-cvd-bg.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/S/P/SP-60-CVD-SG.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/p/splash-90-blk.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/S/P/SPLASH-100.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:28.531430",
      "url": "https://www.cartersdirect.co.uk/ovens-hobs-hoods/cooking/splashback.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258073"
    },
    {
      "id": "preparation-drawers",
      "name": "Preparation Drawers",
      "brand": "Preparation",
      "model": "",
      "price": 561.99,
      "currency": "GBP",
      "description": "High-quality ovens from Preparation",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/p/cpr115n.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/s/hsc140a51.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/c/screenshot_2023-10-24_103001.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/smeg-cpr115s-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/7/17930197_n1aha01g0_stp_def.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:28.554553",
      "url": "https://www.cartersdirect.co.uk/ovens-hobs-hoods/cooking/warming-drawer.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258079"
    },
    {
      "id": "double-builtunder-oven",
      "name": "Double built-under oven",
      "brand": "Double",
      "model": "",
      "price": 437.99,
      "currency": "GBP",
      "description": "High-quality ovens from Double",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/d/d/dd_7.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pim_31433171_pi-b377fd32-3284-476e-90da-476aef584ad0.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/7/17pi865e23f2f9cd4933b885964d03745a22.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/1/f102292_1000x1000_frontal.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/d/u/du2540bl_1.jpg"
      ],
      "category": "ovens",
      "subcategory": "double-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:30.249652",
      "url": "https://www.cartersdirect.co.uk/cooking/ovens/oven-double-b-under.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258096"
    },
    {
      "id": "warming-drawers",
      "name": "Warming Drawers",
      "brand": "Warming",
      "model": "",
      "price": 561.99,
      "currency": "GBP",
      "description": "High-quality ovens from Warming",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/p/cpr115n.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/c/screenshot_2023-10-24_103001.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/smeg-cpr115s-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/7/17930197_n1aha01g0_stp_def.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/i/bic510ns0b.alt1.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:30.261050",
      "url": "https://www.cartersdirect.co.uk/ovens-hobs-hoods/cooking/warming-drawer/warming-drawer.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258102"
    },
    {
      "id": "traditional-ovens",
      "name": "Traditional Ovens",
      "brand": "Traditional",
      "model": "",
      "price": null,
      "currency": "GBP",
      "description": "High-quality ovens from Traditional",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/Miele_Logo.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/miele-wirelessfoodprobe.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/miele-moistureplus.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/miele-specialapplications.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/miele-telescopicrunners.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:30.271350",
      "url": "https://www.cartersdirect.co.uk/other-info/miele-information/miele-conventional-ovens.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258107"
    },
    {
      "id": "builtin-ovens",
      "name": "Built-In Ovens",
      "brand": "Built-In",
      "model": "",
      "price": 269.99,
      "currency": "GBP",
      "description": "High-quality ovens from Built-In",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_bsf60ss_a_06102120240509-1653-1xucz5v.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_bsf60wh_a_06102120240502-1653-7x6v3u_1_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/61on1fchhel._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/y/u/yuntitled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/b/hbg674bb1b.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:30.600159",
      "url": "https://www.cartersdirect.co.uk/cooking/ovens.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258112"
    },
    {
      "id": "integrated-microwave-ovens",
      "name": "Integrated Microwave Ovens",
      "brand": "Integrated",
      "model": "",
      "price": 249.99,
      "currency": "GBP",
      "description": "High-quality ovens from Integrated",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/m/w/mwi-120-gx-uk-microwaves-1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/_/f_3_9.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/5/158862-1600-auto.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/7/1/71ngrcnuoil._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/_/p_2_3.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/u/n/undddddtitled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/h/ghg_2_.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/o/tower_t24034white.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/b/aboamd2002m_main.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/m/sm4420wht.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.957089",
      "url": "https://www.cartersdirect.co.uk/cooking/microwave/combination-oven.html",
      "data_merged": true,
      "categorization_fixed_at": "2025-06-19T18:00:38.258117"
    },
    {
      "id": "built-in-oven-combi-mwave-steam",
      "name": "Built in oven combi mwave + steam",
      "brand": "Built",
      "model": "",
      "price": 2799.99,
      "currency": "GBP",
      "description": "High-quality ovens from Built",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/d/g/dgm7340_cs_miele_steamoven_01_l.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby_1.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_5_.png",
        "https://www.cartersdirect.co.uk/media/wysiwyg/awards1_1_.png"
      ],
      "category": "ovens",
      "subcategory": "combination",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:31.498978",
      "url": "https://www.cartersdirect.co.uk/cooking/ovens/steamcombinationoven.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258122"
    },
    {
      "id": "microwave-oven-with-grill",
      "name": "Microwave Oven with Grill",
      "brand": "Microwave",
      "model": "",
      "price": 169.99,
      "currency": "GBP",
      "description": "High-quality ovens from Microwave",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/f/ffggds.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/2/123456.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/f/ffffffffffffffffffffff.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/m/6/m6012sc-clst-4.jpg",
        "https://www.cartersdirect.co.uk/media/amasty/amlabel/333Untitle333d_1.png"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:36.770226",
      "url": "https://www.cartersdirect.co.uk/cooking/microwave/microwaveoven-grill.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258127"
    },
    {
      "id": "steam-ovens",
      "name": "Steam Ovens",
      "brand": "Steam",
      "model": "",
      "price": null,
      "currency": "GBP",
      "description": "High-quality ovens from Steam",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/Miele_Logo.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/Steamoven.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/steamoven-wireless-probe.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/Miele-Motorised_lift-up_fascia_panel.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/payby.png"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:38.380189",
      "url": "https://www.cartersdirect.co.uk/other-info/miele-information/miele-steam-ovens.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258132"
    },
    {
      "id": "built-in-oven-with-steam-function",
      "name": "Built in oven with steam function",
      "brand": "Built",
      "model": "",
      "price": 329.99,
      "currency": "GBP",
      "description": "High-quality ovens from Built",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/1/f155039_1000x1000_frontal.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/q/hqa534bw3b_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_3_30.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/q/hqa534bb3b_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/h/q/hqa574bb3b_product_image_standard__600x600px_1.png"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:38.817296",
      "url": "https://www.cartersdirect.co.uk/cooking/ovens/steam-oven.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258137"
    },
    {
      "id": "built-in-double-oven",
      "name": "Built in Double oven",
      "brand": "Built",
      "model": "",
      "price": 437.99,
      "currency": "GBP",
      "description": "High-quality ovens from Built",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/f/ffffffffffffffffffffqwe.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/d/idd6340bl.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pim_31433553_pi-104ad3a9-d2b5-4957-b14b-6f6b8166d8e0.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/0/0/009cdfy22309x_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/l/flavel_oven_flv92fx_stainlesssteel_frontclosed.jpg"
      ],
      "category": "ovens",
      "subcategory": "double-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:39.106897",
      "url": "https://www.cartersdirect.co.uk/cooking/ovens/oven-double-built-in.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258175"
    },
    {
      "id": "coffeemakers-built-in",
      "name": "Coffeemakers built in",
      "brand": "Coffeemakers",
      "model": "",
      "price": 2562.99,
      "currency": "GBP",
      "description": "High-quality ovens from Coffeemakers",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/t/ctl7181b0_product_image_standard__600x600px_3.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/l/cl4tt11g0_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/t/ct718l1b0_product_image_standard__600x600px_1.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/p/fp-04-eb60dsx1-10-mug-au-nz-dp-00.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/v/cva7845obbl.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:39.680647",
      "url": "https://www.cartersdirect.co.uk/cooking/ovens/coffeemaker-built-in.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258196"
    },
    {
      "id": "splashback",
      "name": "Splashback",
      "brand": "Splashback",
      "model": "",
      "price": 119.99,
      "currency": "GBP",
      "description": "High-quality ovens from Splashback",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/p/sp-60-cvd-bg.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/p/sp-70-cvd-bg.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/S/P/SP-60-CVD-SG.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/p/splash-90-blk.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/S/P/SPLASH-100.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:40.017167",
      "url": "https://www.cartersdirect.co.uk/ovens-hobs-hoods/cooking/splashback/splashback.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258206"
    },
    {
      "id": "oven-accessories",
      "name": "Oven Accessories",
      "brand": "Oven",
      "model": "",
      "price": 99.99,
      "currency": "GBP",
      "description": "High-quality ovens from Oven",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/3/1/31nipeh5jwl._ac_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/G/R/GRID-A00608.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/n/0/n0chuvph638466945244370101.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/616lajejm_l._sl1024_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/d/h/dhz5605_1_classic.jpg"
      ],
      "category": "ovens",
      "subcategory": "single-built-in",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:40.135319",
      "url": "https://www.cartersdirect.co.uk/cooking/ovens/cooker-hoods.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258216"
    }
  ],
  "cookers": [
    {
      "id": "belling-bel-rca-cookcentre-90e-blk-electric-range-cooker-wit",
      "name": "Belling BEL RCA COOKCENTRE 90E BLK Electric Range Cooker with Ceramic Hob",
      "brand": "Belling",
      "price": 1498.99,
      "currency": "GBP",
      "description": "Best price on Belling in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Belling BEL RCA COOKCENTRE 90E BLK 90Cm Range Cooker E Ceramic Black 444411791",
      "specifications": {
        "energy_rating": "A"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T18:00:31.948304",
      "category": "cookers",
      "subcategory": "range-freestanding",
      "features": [
        "5 Zone Ceramic Hob",
        "90cm Electric Range Cooker-Ceramic Hob",
        "Colour: Black",
        "Right net capacity 81 L",
        "Multifunction Oven"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/05039256c443b19f0f90267eaea8e601/4/4/444411791_bel_rca_co-caxsrgzx.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411791_bel_rca_co-caxsrgzx.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411791_bel_rca_co-1im9b-yg.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411791_bel_rca_co-qx2xnmod.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411791_bel_rca_co-rivldff0.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/610yzzektkl._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK90C230C.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK100C210C.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK100C210K.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK100C210S.png"
      ],
      "dimensions": "",
      "model": "COOKCENTRE",
      "url": "https://www.cartersdirect.co.uk/belling-bel-rca-cookcentre-90e-blk.html",
      "original_price": 1199.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966377",
      "categorization_fixed_at": "2025-06-19T18:00:38.258500",
      "data_merged": true
    },
    {
      "id": "belling-bel-rca-farmhouse-90e-blk-electric-range-cooker-with",
      "name": "Belling BEL RCA FARMHOUSE 90E BLK Electric Range Cooker with Ceramic Hob",
      "brand": "Belling",
      "price": 1498.99,
      "currency": "GBP",
      "description": "Best price on Belling in Brighton, Haywards Heath, Worthing, Storrington and Horsham Sussex? We have a huge selection  on display. Buy online or visit in store for Belling BEL RCA FARMHOUSE 90E BLK 90Cm Range Cooker Electric 5 Zones Black 444411817",
      "specifications": {
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.872408",
      "category": "cookers",
      "subcategory": "range-freestanding",
      "features": [
        "5 Ceramic Zones",
        "90cm Electric Range Cooker-Ceramic Hob",
        "Colour: Black",
        "Top Left 33lt",
        "Right Tall 81lt"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/05039256c443b19f0f90267eaea8e601/4/4/444411817_bel_rca_fa-xtv71ugz_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411817_bel_rca_fa-xtv71ugz_1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411817_bel_rca_fa-4s5ml1rt.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411817_bel_rca_fa-jx6iralq.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/f25187a21099bc7123c4a5b3ec2f3d23/4/4/444411817_bel_rca_fa-xtnmhvic.jpg"
      ],
      "dimensions": "900mm (h) \u00a0x\u00a0\n    896mm (w) \u00a0x\u00a0\n    600mm (d)",
      "model": "FARMHOUSE",
      "url": "https://www.cartersdirect.co.uk/belling-bel-rca-farmhouse-90e-blk.html",
      "original_price": 1199.0,
      "pricing_updated_at": "2025-06-19T17:56:17.966382",
      "categorization_fixed_at": "2025-06-19T18:00:38.258562"
    },
    {
      "id": "leisure-cs100c510x-range-cooker",
      "name": "Leisure CS100C510X Range Cooker",
      "brand": "Leisure",
      "price": 1474.99,
      "currency": "GBP",
      "description": "Best price on Leisure CS100C510 in Brighton Hayward\u2019s Heath Worthing Southwick or Horsham Sussex? Have a huge selection of Range Cookers on display. Buy online or visit in store. Hundreds of models in stock, ready for delivery and installation.",
      "specifications": {
        "energy_rating": "B"
      },
      "in_stock": false,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T16:35:07.872473",
      "category": "cookers",
      "subcategory": "range-freestanding",
      "features": [
        "100cm Electric Range Cooker-Ceramic Hob",
        "Colour: Stainless steel",
        "100cm Range Cooker",
        "Energy Rating"
      ],
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/9863e674de07746d469f166832d7da23/c/s/cs100c510x.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/c/s/cs100c510x.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/c/s/cs100c510x.alt1.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/c/s/cs100c510x.alt2.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/ea8396ccd1fe3eb6e08c74c7e37143a5/c/s/cs100c510x.alt3.jpg"
      ],
      "dimensions": "",
      "model": "CS100C510X",
      "url": "https://www.cartersdirect.co.uk/leisure-cs100c510x.html",
      "original_price": 1179.99,
      "pricing_updated_at": "2025-06-19T17:56:17.966386",
      "categorization_fixed_at": "2025-06-19T18:00:38.258578"
    },
    {
      "id": "table-top-cooker",
      "name": "Table top Cooker",
      "brand": "Table",
      "model": "",
      "price": 159.99,
      "currency": "GBP",
      "description": "High-quality cookers from Table",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/o/tower_t14043_400024272_3401000027.jpg.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/8/1/81f_8imhcpl._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/-/s-l1600_12_4.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/g/igenix_ig7130_997331_34-0100-0157.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/o/tower_t14044_400024276_3401000027.jpg.jpg"
      ],
      "category": "cookers",
      "subcategory": "electric-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:28.447403",
      "url": "https://www.cartersdirect.co.uk/cooking/cooker-freestanding/cooker-table-top.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258597"
    },
    {
      "id": "dual-fuel-cooker",
      "name": "Dual Fuel Cooker",
      "brand": "Dual",
      "model": "",
      "price": 687.99,
      "currency": "GBP",
      "description": "High-quality cookers from Dual",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/6/165904-1200-auto.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/6/165940-1200-auto.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/1/6/166025-1200-auto.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_287326_2679.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_287333_2679.jpg"
      ],
      "category": "cookers",
      "subcategory": "electric-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:28.481597",
      "url": "https://www.cartersdirect.co.uk/cooking/cooker-freestanding/cooker-dualfuel.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258603"
    },
    {
      "id": "freestanding-cookers",
      "name": "Freestanding Cookers",
      "brand": "Freestanding",
      "model": "",
      "price": 536.99,
      "currency": "GBP",
      "description": "High-quality cookers from Freestanding",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/f/afc6550wh_amica_oven_01_l.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/t/o/tower_t14043_400024272_3401000027.jpg.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/8/1/81f_8imhcpl._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/-/s-l1600_12_4.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/g/igenix_ig7130_997331_34-0100-0157.png"
      ],
      "category": "cookers",
      "subcategory": "electric-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:30.131628",
      "url": "https://www.cartersdirect.co.uk/cooking/cooker-freestanding.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258610"
    },
    {
      "id": "gas-cooker",
      "name": "Gas Cooker",
      "brand": "Gas",
      "model": "",
      "price": 320.99,
      "currency": "GBP",
      "description": "High-quality cookers from Gas",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/2/8/280ze501w_main.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_studio2_b20221030-11935-t2qw1z.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/f/1/f156776_1000x1000_frontal.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/61conzskv6l._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/b/l/blomberg_ggs9151w_100060147_3401000296.png"
      ],
      "category": "cookers",
      "subcategory": "gas-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:30.964581",
      "url": "https://www.cartersdirect.co.uk/cooking/cooker-freestanding/cooker-gas.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258615"
    },
    {
      "id": "cooker-hoods",
      "name": "Cooker Hoods",
      "brand": "Cooker",
      "model": "",
      "price": null,
      "currency": "GBP",
      "description": "High-quality cookers from Cooker",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/wysiwyg/cms-pages/Miele_Logo.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/Conactivity-2.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/Superior-Energy-Efiiciency.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/miele-grease-filters.jpg",
        "https://www.cartersdirect.co.uk/media/wysiwyg/miele-highlights/Silence.jpg"
      ],
      "category": "cookers",
      "subcategory": "electric-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:38.133758",
      "url": "https://www.cartersdirect.co.uk/other-info/miele-information/miele-cooker-hoods.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258620"
    },
    {
      "id": "dual-fuel-range-cooker",
      "name": "Dual Fuel Range Cooker",
      "brand": "Dual",
      "model": "",
      "price": 1237.99,
      "currency": "GBP",
      "description": "High-quality cookers from Dual",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_155560_2679.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK90F232K.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK110F232C.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/k/ck100f232k.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_277161_2679.jpg"
      ],
      "category": "cookers",
      "subcategory": "range-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:38.845808",
      "url": "https://www.cartersdirect.co.uk/cooking/range-cooker/rangecooker-dualfuel.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258626"
    },
    {
      "id": "range-cookers",
      "name": "Range Cookers",
      "brand": "Range",
      "model": "",
      "price": 319.99,
      "currency": "GBP",
      "description": "High-quality cookers from Range",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/2/4/24637_z_901482901356-zoccolomontatoaa-beu-tk100nrrxt-carbonio.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/6/1/610yzzektkl._ac_sl1500_.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK90C230C.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/j/_/j.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_155560_2679.jpg"
      ],
      "category": "cookers",
      "subcategory": "range-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:40.718527",
      "url": "https://www.cartersdirect.co.uk/cooking/range-cooker.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258654"
    },
    {
      "id": "electric-range-cooker-with-induction-hob",
      "name": "Electric Range Cooker with Induction Hob",
      "brand": "Electric",
      "model": "",
      "price": 1574.99,
      "currency": "GBP",
      "description": "High-quality cookers from Electric",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/k/ck100d210k.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/m/image_xl_277445_2679.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/c/x/cx91imbl.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/s/c/screenshot_2024-11-08_141015.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/4/4/444411832_bel_rca_fa-dcu-afdf.jpg"
      ],
      "category": "cookers",
      "subcategory": "range-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:41.436987",
      "url": "https://www.cartersdirect.co.uk/cooking/range-cooker/rangecookerinduction.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258661"
    },
    {
      "id": "gas-range-cooker",
      "name": "Gas Range Cooker",
      "brand": "Gas",
      "model": "",
      "price": 1237.99,
      "currency": "GBP",
      "description": "High-quality cookers from Gas",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/j/_/j.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK90G232K.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK100G232C.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/C/K/CK100G232K.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/k/i/kichener-90_df_cream.jpg"
      ],
      "category": "cookers",
      "subcategory": "gas-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:43.591568",
      "url": "https://www.cartersdirect.co.uk/cooking/range-cooker/rangecooker-gas.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258666"
    },
    {
      "id": "electric-cooker",
      "name": "Electric Cooker",
      "brand": "Electric",
      "model": "",
      "price": 536.99,
      "currency": "GBP",
      "description": "High-quality cookers from Electric",
      "specifications": {
        "energy_rating": "A"
      },
      "images": [
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/a/f/afc6550wh_amica_oven_01_l.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/p/i/pikapak_delta50w_b20210915-20216-16qxr8.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/5/-/5-49_1500_1500.jpg",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/g/g/ggggtled.png",
        "https://www.cartersdirect.co.uk/media/catalog/product/cache/90693ea6175246529ca4f1501b6d6b70/i/d/id5e92kmw_1_supersize.jpg"
      ],
      "category": "cookers",
      "subcategory": "electric-freestanding",
      "in_stock": true,
      "warranty": "12 months",
      "installation_available": true,
      "scraped_at": "2025-06-19T17:58:43.701581",
      "url": "https://www.cartersdirect.co.uk/cooking/cooker-freestanding/cooker-electric.html",
      "categorization_fixed_at": "2025-06-19T18:00:38.258671"
    }
  ]
}