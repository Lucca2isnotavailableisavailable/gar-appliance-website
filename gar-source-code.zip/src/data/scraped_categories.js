// Categories based on actual scraped data from Green Appliance Repairs
import productsData from './products_by_category.js'

const createCategoryFromProducts = (categorySlug, categoryName, products) => {
  const categoryProducts = products.filter(p => p.category === categorySlug)
  
  // Get unique subcategories
  const subcategories = [...new Set(categoryProducts.map(p => p.subcategory))]
    .filter(sub => sub && sub !== 'unknown')
    .map(subcat => ({
      slug: subcat,
      name: subcat.charAt(0).toUpperCase() + subcat.slice(1).replace('-', ' '),
      products: categoryProducts.filter(p => p.subcategory === subcat)
    }))
  
  // Find the first product with images to use as category image
  const productWithImage = categoryProducts.find(p => p.images && p.images.length > 0)
  const categoryImage = productWithImage ? productWithImage.images[0] : `/images/categories/${categorySlug}.jpg`
  
  return {
    slug: categorySlug,
    name: categoryName,
    productCount: categoryProducts.length,
    priceRange: {
      min: Math.min(...categoryProducts.filter(p => p.price).map(p => p.price)),
      max: Math.max(...categoryProducts.filter(p => p.price).map(p => p.price))
    },
    subcategories,
    products: categoryProducts,
    brands: [...new Set(categoryProducts.map(p => p.brand))],
    image: categoryImage
  }
}

// Get all products from the imported data
const allProducts = Object.values(productsData).flat()

// Generate categories from scraped data with real products
const scrapedCategories = [
  createCategoryFromProducts('dishwashers', 'Dishwashers', allProducts),
  createCategoryFromProducts('tumble-dryers', 'Tumble Dryers', allProducts),
  createCategoryFromProducts('washer-dryers', 'Washer Dryers', allProducts),
  createCategoryFromProducts('washing-machines', 'Washing Machines', allProducts),
  createCategoryFromProducts('appliances', 'Appliances', allProducts),
  createCategoryFromProducts('ovens', 'Ovens', allProducts),
  createCategoryFromProducts('cookers', 'Cookers', allProducts),
].filter(cat => cat.productCount > 0) // Only include categories with products

// Generate categories from scraped data
const generateCategories = () => {
  return scrapedCategories
}

export default generateCategories()

export const getCategoryBySlug = (slug) => {
  return scrapedCategories.find(cat => cat.slug === slug)
}

export const getProductsByCategory = (categorySlug, subcategorySlug = null) => {
  const category = getCategoryBySlug(categorySlug)
  if (!category) return []
  
  let products = category.products
  if (subcategorySlug) {
    const subcategory = category.subcategories.find(sub => sub.slug === subcategorySlug)
    products = subcategory ? subcategory.products : []
  }
  
  return products
}

export const getAllBrands = () => {
  return [...new Set(scrapedCategories.flatMap(cat => cat.brands))]
}

export const getProductById = (productId) => {
  for (const category of scrapedCategories) {
    const product = category.products.find(p => p.id === productId)
    if (product) return product
  }
  return null
}
