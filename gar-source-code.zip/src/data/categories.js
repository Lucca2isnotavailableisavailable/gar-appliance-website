const categories = [
  {
    slug: 'washing-machines',
    name: 'Washing Machines',
    image: 'https://www.cartersdirect.co.uk/media/catalog/category/WM-category.jpg',
    subcategories: [
      { slug: 'freestanding', name: 'Freestanding', url: 'https://www.cartersdirect.co.uk/laundry/washing-machines/washing-machine.html' },
      { slug: 'integrated', name: 'Integrated', url: 'https://www.cartersdirect.co.uk/laundry/washing-machines/int-washing-machine.html' }
    ]
  },
  {
    slug: 'washer-dryers',
    name: 'Washer Dryers',
    image: 'https://www.cartersdirect.co.uk/media/catalog/category/WD-category.jpg',
    subcategories: [
      { slug: 'freestanding', name: 'Freestanding', url: 'https://www.cartersdirect.co.uk/laundry/washer-dryers/washer-dryer.html' },
      { slug: 'integrated', name: 'Integrated', url: 'https://www.cartersdirect.co.uk/laundry/washer-dryers/int-washer-dryer.html' }
    ]
  },
  {
    slug: 'tumble-dryers',
    name: 'Tumble Dryers',
    image: 'https://www.cartersdirect.co.uk/media/catalog/category/TD-category.jpg',
    subcategories: [
      { slug: 'condenser', name: 'Condenser', url: 'https://www.cartersdirect.co.uk/laundry/tumble-dryer/condensertumbledryer.html' },
      { slug: 'vented', name: 'Vented', url: 'https://www.cartersdirect.co.uk/laundry/tumble-dryer/vented-tumbledryer.html' }
    ]
  },
  {
    slug: 'dishwashers',
    name: 'Dishwashers',
    image: 'https://www.cartersdirect.co.uk/media/catalog/category/DW-category.jpg',
    subcategories: [
      { slug: 'freestanding-60cm', name: 'Freestanding 60cm', url: 'https://www.cartersdirect.co.uk/dishwashers/freestanding-dishwashers/dishwashers-60cm.html' },
      { slug: 'integrated-45cm', name: 'Integrated 45cm', url: 'https://www.cartersdirect.co.uk/dishwashers/integrateddishwasher/dishwashers-45cm.html' }
    ]
  },
  {
    slug: 'ovens',
    name: 'Ovens',
    image: 'https://www.cartersdirect.co.uk/media/catalog/category/Ovens-category.jpg',
    subcategories: [
      { slug: 'single-built-in', name: 'Single Built-in', url: 'https://www.cartersdirect.co.uk/cooking/ovens/oven-single-built-in.html' },
      { slug: 'double-built-under', name: 'Double Built-under', url: 'https://www.cartersdirect.co.uk/cooking/ovens/oven-double-b-under.html' }
    ]
  },
  {
    slug: 'cookers',
    name: 'Cookers',
    image: 'https://www.cartersdirect.co.uk/media/catalog/category/Cookers-category.jpg',
    subcategories: [
      { slug: 'electric-freestanding', name: 'Electric Freestanding', url: 'https://www.cartersdirect.co.uk/cooking/cooker-freestanding/cooker-electric.html' },
      { slug: 'electric-range', name: 'Electric Range', url: 'https://www.cartersdirect.co.uk/cooking/range-cooker/rangecooker-electric.html' }
    ]
  }
]

export default categories 